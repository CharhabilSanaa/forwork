<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

	function insert_historique_crone($libelle,$type,$categorie,$idrapport,$typeEnvoi)
		{
			$sql = "INSERT INTO  `new_historique_crone`.`suivi_crone` (`id_crone`, `libelle`, `date_debut`, `etat`, `type`, `etat_affichage`,`categorie`,`idrapports`,`typeEnvoi`) 
			VALUES ( NULL,'".$libelle."', Now(), 0,  '".$type."',1,'".$categorie."','".$idrapport."','".$typeEnvoi."')";
			 
			 $link = ma_db_connexion(); 
			$result=mysqli_query($link,$sql);
			mysqli_close($link);
			 
		}
	/*********************************************************************************************************/
	function update_historique_crone($libelle,$type)
		{    $link = ma_db_connexion(); 
			 $sql = "SELECT `id_crone` FROM  `new_historique_crone`.`suivi_crone` where `libelle` ='".$libelle."'  AND  `type` ='".$type."' AND `etat` =0 ORDER BY `id_crone` DESC LIMIT 1";
			
					if ($result=mysqli_query($link,$sql)) 
					{
						if(mysqli_num_rows($result)>0)
							{ $i=0;
								while ($row = mysqli_fetch_assoc($result)) 
									{
										$idHistorique = $row['id_crone'];
										$i++;
									}
						 
							}
						
									mysqli_free_result($result);	
					}		
			
				
				$SQL2 = "UPDATE  `new_historique_crone`.`suivi_crone` SET  `date_fin` = NOW(), `etat` = 1 	WHERE  `id_crone` ='".$idHistorique."'";
		    	$res=mysqli_query($link,$SQL2);
				// mysqli_free_result($res);	
			
			mysqli_close($link);				
	 
		} 
		
function debut_traitement($id_projet,$id_traitement,$id_serveur)
{

$sql="INSERT INTO new_historique_crone.suivi_traitement_projets (id_traitement,id_projet,date_debut) VALUES ('$id_traitement','$id_projet',NOW())";
$link = ma_db_connexion(); 	
mysqli_query($link,$sql); 
mysqli_close($link);	
}		
/*******************************************************************/
function fin_traitement($id_projet,$id_traitement,$id_serveur){
$sql="UPDATE new_historique_crone.suivi_traitement_projets SET date_fin=NOW() 
WHERE id_traitement = '$id_traitement' AND  id_projet = '$id_projet'  ORDER by id_suivi DESC LIMIT 1";
$link = ma_db_connexion(); 	
mysqli_query($link,$sql); 
mysqli_close($link);		
}		
/*******************************************************************/
function condition_traitement($id_traitement,$id_serveur){
	
		 $link = ma_db_connexion(); 
		$sql="SELECT * FROM new_historique_crone.global_etat_traitement_serveur WHERE etat_global=1 AND  id_serveur='$id_serveur'";
				if ($result=mysqli_query($link,$sql)) 
					{
						if (mysqli_num_rows($result)>0)
							{
							    	$sqlTraitement="SELECT * FROM new_historique_crone.table_traitement_projets WHERE id_traitement  = '$id_traitement'  AND etat_activation=1";
								  if ($res=mysqli_query($link,$sqlTraitement)) 
									{
								if (mysqli_num_rows($res)>0)
									{
										return 1;
									} 
								else 
									{ 
										return 0; 
									}
									
								}							
									mysqli_free_result($res);	
							}
						else 
							{ 
								return 0; 
							}	
			mysqli_free_result($result);	
					}						
	mysqli_close($link);			
}
/*******************************************************************/
function regle_heure_backoffice()
{  
				$heure_actuel=0;
			    $sql="SELECT  `horaire_front` FROM `iprc_authentification`.`new_regle_heure` WHERE `id_regle_heure`='1'";
				$link = ma_db_connexion(); 
				if ($result=mysqli_query($link,$sql)) 
					{
						if(mysqli_num_rows($result)>0)
							{ $i=0;
								while ($row = mysqli_fetch_assoc($result)) 
									{
										$heure_actuel=$row["horaire_front"];
										$i++;
									}
						 
							}
										
					}	

				mysqli_free_result($result);	
				mysqli_close($link);
				return $heure_actuel; 	
} 
/*******************************************************************/
function verifGabEvenementionnelle()
{ 
  $sql="SELECT `id_filiale` FROM `new_filiale` WHERE `id_filiale`='8888' AND `etat_activation`=1";
	
				$link = ma_db_connexion(); 
				if ($result=mysqli_query($link,$sql)) 
					{
						if(mysqli_num_rows($result)>0)
							{ $i=0;
									return 1;
							}
						else
							{
								return 0; 
							}							
									mysqli_free_result($result);	
					}						
				mysqli_close($link);		
	
	
	
	
} 
/*******************************************************************/
function getDestinataireMail($idrapport,$mail)
{ 
  $sql="SELECT `name`, `email`, `id_type` FROM  `new_historique_crone`.`listContactRapport`,`new_historique_crone`.`listContact`
		WHERE `new_historique_crone`.`listContactRapport`.`id_contact`=`new_historique_crone`.`listContact`.`id_contact` AND `id_rapport` = '".$idrapport."'  AND `etat` = 1
		ORDER BY  `listContactRapport`.`IDCR` ASC";
				$link = ma_db_connexion(); 
				if ($result=mysqli_query($link,$sql)) 
					{
						if(mysqli_num_rows($result)>0)    
						{$i=0;
							while ($row = mysqli_fetch_assoc($result)) 
								{
									if($row["id_type"]==1){$mail->addAddress($row["email"],$row["name"]);}
									if($row["id_type"]==2){$mail->AddCC($row["email"],$row["name"]);}
									if($row["id_type"]==3){$mail->addBcc($row["email"],$row["name"]);}
								}
						}
						mysqli_free_result($result);	
					}						
				mysqli_close($link);		
							
}
/*******************************************************************/
function condition_rapport($id_projet,$idrapport,$id_serveur){
$link = ma_db_connexion(); 
$sqlSelectProjet=mysqli_query($link,"SELECT * FROM new_historique_crone.global_etat_traitement_serveur WHERE etat_global=1 AND  id_serveur='$id_serveur' ");
if (mysqli_num_rows($sqlSelectProjet)>0){
	$sqlSelectTraitement=mysqli_query($link,"SELECT * FROM new_historique_crone.suivi_rapport WHERE idrapport  LIKE '$idrapport'  AND etat_activation=1");
	if (mysqli_num_rows($sqlSelectTraitement)>0){
		mysqli_close($link);
		return 1;
	} else { 
	mysqli_close($link);
	return 0; }		
}
else { 
mysqli_close($link);
return 0; }		
}
/*******************************************************************/






?>