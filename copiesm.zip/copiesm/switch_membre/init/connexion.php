<?php  include("init.php");



function ma_db_connexion()
{

	$id_connexion =0;
	$id_connexion = mysqli_connect(HOST, USER, PSWD,DATABASE);
	
	if(mysqli_connect_errno($id_connexion))
	{ 
		echo "Failed to connect to MySQL Database: " . mysqli_connect_error();
		return $id_connexion;
	}
	else
	{  
		mysqli_set_charset($id_connexion, "utf8");
		  return $id_connexion;
		
	}	
		

}

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

?>