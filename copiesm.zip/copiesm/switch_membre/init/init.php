<?php
 //  LATER include("/var/www/html/param.php");


  DEFINE('HOST', '192.168.1.7');
  DEFINE('USER', 'HpsSwitchMembre');
  DEFINE('PSWD', 'HpsSM22');
  DEFINE('DATABASE', 'fichiers_switch_membre');
  ///////////////////////////////////////////
  
?>

