<?php
 // if (($_SERVER["REMOTE_ADDR"]=="192.168.1.197") || ($_SERVER["REMOTE_ADDR"]=="192.168.1.30") || ($_SERVER["REMOTE_ADDR"]=="192.168.1.10") || ($_SERVER["REMOTE_ADDR"]=="192.168.2.133") || ($_SERVER["REMOTE_ADDR"]=="192.168.0.231") || ($_SERVER["REMOTE_ADDR"]=="192.168.0.228"))
	{	

		header('Content-Type: text/html; charset=iso-8859-1');

		set_time_limit(0);
		ini_set('memory_limit', '-1');      
		error_reporting(E_ALL);
		error_reporting(E_ALL ^ E_DEPRECATED); 
		ini_set('display_errors', TRUE); 
		ini_set('display_startup_errors', TRUE); 
		include("../init/function_cron.php");  
		include "get_function.php";
		include("../init/connexion.php");
		include "get_date_courant.php";
		// echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
		// require_once "../PHPExcel/PHPExcel.php";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<link rel="stylesheet" href="coreui.min.css">
</head>
<body>
		 <?php		 
		echo $dt_courant;
		echo '<br>';
		echo $date_courant;	
		if(empty($libelle)){$libelle="File mcc";} 
         ?>
        <div id="page-wrapper" style=" margin: 0px 0 0 5px;">		
            <div class="row">
                <div class="col-sm-12 col-lg-12">
					<?php 		
		
						$ancien_fichier = '../recupe_piece_joint/File_mccpo_'.$dt_courant.'.csv';
						if(file_exists($ancien_fichier))
							{	
								echo 'File file_buffer_mcc exsit';
								$nouveau_fichier = '../recupe_piece_joint/file_buffer_mcc/File_mccpo_'.$dt_courant.'.csv';
								copy($ancien_fichier, $nouveau_fichier) or die("impossible de copier $ancien_fichier à $nouveau_fichier");
								// unlink($ancien_fichier);
								importer_data_piece_csv_joint_file_mcc_vers_bdd($nouveau_fichier,$dt_courant,$libelle);
								
							}
						else
							{
								echo 'File file_buffer_mcc not exsit';
							}
						
					
					?>
                </div>
           </div>
		</div>
</body>
</html>
<?php 
	}
?>
   