<?php

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_type_banque($name_table,$libelle_bank)
{      
					
					$link = ma_db_connexion();
					$etat_bank = '';	
					$sql = "SELECT  `etat_bank` FROM `".$name_table."`"; 
					if($libelle_bank<>''){$sql = $sql." WHERE `libelle_bank` IN('".mysqli_real_escape_string($link,$libelle_bank)."')";}

				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql carte_gab_tpe vr bdd  0440014747789589895 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0440014747789589895 !');
						}
					if(mysqli_num_rows($result)>0)
						{   $i=0;
							while ($row = mysqli_fetch_assoc($result)) 
								{										
									$etat_bank=$row["etat_bank"];
									$i++;
								}
						}
						
					mysqli_close($link);
					return	$etat_bank;	
						
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function get_array_banque($name_table,$etat_bank)
{      
					
					$link = ma_db_connexion();
					$libelle_bank = array();	
					$sql = "SELECT  `libelle_bank` FROM `".$name_table."`"; 
					if($etat_bank<>''){$sql = $sql." WHERE `etat_bank` IN(".mysqli_real_escape_string($link,$etat_bank).")";}
					$sql = $sql." ORDER BY `libelle_bank` ASC";
					mysqli_query($link,"SET CHARACTER SET 'utf8'");
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql carte_gab_tpe vr bdd  044001474775 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 044001474775 !');
						}
					if(mysqli_num_rows($result)>0)
						{   $i=0;
							while ($row = mysqli_fetch_assoc($result)) 
								{										
									$libelle_bank[$i]=$row["libelle_bank"];
									$i++;
								}
						}
						
					mysqli_close($link);
					return	$libelle_bank;	
						
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_total_rejet($libelle_banque,$name_table,$date_courant)
{      
					
					$link = ma_db_connexion();
					$nb_rejet = 0;	
					$sql = "SELECT  SUM(`nbr_tech_reject`) as nbr_reject  FROM `".$name_table."` 
					WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'";
					if($libelle_banque<>''){$sql = $sql." AND `bank_name` IN('". implode("','", $libelle_banque)."')";}
					// echo $sql; 
					mysqli_query($link,"SET CHARACTER SET 'utf8'");
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql carte_gab_tpe vr bdd  000007988866156456465546 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 000007988866156456465546 !');
						}
					if(mysqli_num_rows($result)>0)
						{   $i=0;
							while ($row = mysqli_fetch_assoc($result)) 
								{										
									$nb_rejet=$row["nbr_reject"];
									$i++;
								}
						}
						
					mysqli_close($link);
					return	$nb_rejet;	
						
}
//////////////////////////////////////////////////////////////////////////
function get_nbr_auto_rejet($date_courant,$name_table,$bank_name)
{
				   $link = ma_db_connexion();
				   $nbr_total=0;
				   $sql1="SELECT `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`
				   FROM `".$name_table."` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
				   AND `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result) 
						{
										error_log("Erreur sql hps membres vr bdd  00000005645645648 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000005645645648 !');
						}				   
					if (mysqli_num_rows($result)>0)
							{ 
						
							while ($row = mysqli_fetch_assoc($result)) 
								{			
											

							                $nbr_total=$row["h0"]+$row["h1"]+$row["h2"]+$row["h3"]+$row["h4"]+$row["h5"]+$row["h6"]+$row["h7"]+$row["h8"]+$row["h9"]+$row["h10"]+$row["h11"]+$row["h12"]+$row["h13"]+$row["h14"]+$row["h15"]+$row["h16"]+$row["h17"]+$row["h18"]+$row["h19"]+$row["h20"]+$row["h21"]+$row["h22"]+$row["h23"];											
								}
							}
					mysqli_close($link);		
					return $nbr_total;
}
//////////////////////////////////////////////////////////////////////////
function update_data_piece_joint_per_hour_in_vers_bdd($date_courant,$name_table)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`, `bank_name`, `percentage_tech_reject`,`nbr_tech_reject`, `nbr_autho`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`,
				   `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`
				   FROM `".$name_table."` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result) 
						{
										error_log("Erreur sql hps membres vr bdd  00000005645645648 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000005645645648 !');
						}				   
					if (mysqli_num_rows($result)>0)
							{ 
						
							while ($row = mysqli_fetch_assoc($result)) 
								{			
											
											$nbr_tech_reject=get_nbr_auto_rejet($date_courant,'stat_file_rejet_per_hour',$row["bank_name"]);
											$nbr_autho=get_nbr_auto_rejet($date_courant,'stat_file_rejet_per_hour_gl',$row["bank_name"]);
											
							                // $nbr_tech_reject=$row["h0"]+$row["h1"]+$row["h2"]+$row["h3"]+$row["h4"]+$row["h5"]+$row["h6"]+$row["h7"]+$row["h8"]+$row["h9"]+$row["h10"]+$row["h11"]+$row["h12"]+$row["h13"]+$row["h14"]+$row["h15"]+$row["h16"]+$row["h17"]+$row["h18"]+$row["h19"]+$row["h20"]+$row["h21"]+$row["h22"]+$row["h23"];											
											

											
											$sql2 = "UPDATE `".$name_table."` SET 
											`nbr_autho` =   '".mysqli_real_escape_string($link,$nbr_autho)."',
											`nbr_tech_reject` =   '".mysqli_real_escape_string($link,$nbr_tech_reject)."'
											WHERE  `bank_name` = '".mysqli_real_escape_string($link,$row["bank_name"])."' ";
											$result2=mysqli_query($link,$sql2);
													if (!$result2)
														{
															error_log("Erreur sql ABTPE 000000056456456481 : ".mysqli_error($link));
															die('ERREUR QUERY ABTPE 000000056456456481 !');
														}										
								}	
						
			
							}
							
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000005645645648 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000005645645648 !');
						}								
					if (mysqli_num_rows($result)>0)
							{ 
						
							while ($row = mysqli_fetch_assoc($result)) 
								{			
											
											$type_banque=get_type_banque('cellule_bank',$row["bank_name"]);
											
											$libelle_banque=get_array_banque('cellule_bank',$type_banque);
											$libelle_banque_global=get_array_banque('cellule_bank','');
											
											$nbr_total_rejet_type_banque=get_total_rejet($libelle_banque,$name_table,$date_courant);
											$nbr_total_rejet=get_total_rejet($libelle_banque_global,$name_table,$date_courant);
											
							                $nbr_tech_reject=$row["nbr_tech_reject"];											
											
											// echo "<br>".$nbr_tech_reject." ----> ".$nbr_total_rejet_type_banque." ----> ".$nbr_total_rejet;
											$taux_rejet=round((($nbr_tech_reject/$row["nbr_autho"])*100),2);
											$taux_rejet_type_banque=round((($nbr_tech_reject/$nbr_total_rejet_type_banque)*100),2);
											$taux_rejet_global=round((($nbr_tech_reject/$nbr_total_rejet)*100),2);
											
											$sql2 = "UPDATE `".$name_table."` SET 
											`percentage_tech_reject` =   '".mysqli_real_escape_string($link,$taux_rejet)."',";
											
											if($name_table=='stat_file_rejet_per_hour_gl')
												{
													$sql2 = $sql2." `percentage_auto_categ_banque` =   '".mysqli_real_escape_string($link,$taux_rejet_type_banque)."',
													`percentage_auto_global` =   '".mysqli_real_escape_string($link,$taux_rejet_global)."'";												
												}

											if($name_table=='stat_file_rejet_per_hour')
												{
													$sql2 = $sql2." `percentage_reject_categ_banque` =   '".mysqli_real_escape_string($link,$taux_rejet_type_banque)."',
													`percentage_reject_global` =   '".mysqli_real_escape_string($link,$taux_rejet_global)."'";												
												}											
											
											$sql2 = $sql2." WHERE  `id_auto` = '".mysqli_real_escape_string($link,$row["id_auto"])."' ";
											$result2=mysqli_query($link,$sql2);
													if (!$result2)
														{
															error_log("Erreur sql ABTPE 00000005645645645665681 : ".mysqli_error($link));
															die('ERREUR QUERY ABTPE 00000005645645645665681 !');
														}										
								}	
						
			
							}							
							
					mysqli_close($link); 			
}
function ajouter_nouvelle_bank($date_courant,$name_table)
{
	

				   $link = ma_db_connexion();
				   $sql1="SELECT  `bank_name` FROM `".$name_table."` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
				   GROUP BY `bank_name`";		

				   $result=mysqli_query($link,$sql1);
 				   if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  000000056456456482 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 000000056456456482 !');
						}				   
					if (mysqli_num_rows($result)>0)
							{						
							while ($row = mysqli_fetch_assoc($result)) 
								{	

										   $sql2="SELECT  `id_auto` FROM `cellule_bank` WHERE `libelle_bank` = '".mysqli_real_escape_string($link,$row["bank_name"])."'";				  
	
										   
										   $result2=mysqli_query($link,$sql2);
										   if (!$result2)
												{
																error_log("Erreur sql hps membres vr bdd  0000000564564564823 : ".mysqli_error($link));
																die('ERREUR QUERY carte_gab_tpe vr bdd 0000000564564564823!');
												}				   
											if (mysqli_num_rows($result2)==0)
													{ 												
		
																$sql3 = "INSERT INTO  `cellule_bank` (`id_auto`, `libelle_bank`, `etat_bank`)
																VALUES ( NULL,'".mysqli_real_escape_string($link,$row["bank_name"])."',2)";
														
																$result3=mysqli_query($link,$sql3);
																if (!$result3)
																		{
																						error_log("Erreur sql hps membres vr bdd  0000878989890006444 : ".mysqli_error($link));
																						die('ERREUR QUERY carte_gab_tpe vr bdd 0000878989890006444  !');
																		}															
															
									
													}	
								}	
							}
					mysqli_close($link); 			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_device_pays($libelle)
{      
					
					$link = ma_db_connexion();
					$sql = "SELECT  `monnaie`  FROM `bank_name` WHERE `code_monnaie` = '".mysqli_real_escape_string($link,substr($libelle, 0, -1))."'";
					// if (mysqli_real_escape_string($link,$libelle)=='OFF US Confrère'){echo "<br>".$sql;}
					// else{echo "<br> libelle =============> ".$libelle;}
					// echo "<br> libelle =============> ".str_replace('\n', '', $libelle);
					// echo "<br> libelle =============> ".substr($libelle, 0, -1);
					// echo "<br>".$sql;
					mysqli_query($link,"SET CHARACTER SET 'utf8'");
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0000079888661 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0000079888661 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["monnaie"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}

						
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_reseau_card($libelle)
{      
					
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `reseau_master_card_visa` WHERE `libelle` = '".mysqli_real_escape_string($link,$libelle)."'";
					// if (mysqli_real_escape_string($link,$libelle)=='OFF US Confrère'){echo "<br>".$sql;}
					// else{echo "<br> libelle =============> ".$libelle;}
					// echo "<br> libelle =============> ".str_replace('\n', '', $libelle);
					// echo "<br> libelle =============> ".substr($libelle, 0, -1);
					// echo "<br>".$sql;
					mysqli_query($link,"SET CHARACTER SET 'utf8'");
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000798881 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000798881 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_reseau_us($libelle_bank)
{       
					
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `reseau_us` WHERE `libelle` = '".mysqli_real_escape_string($link,$libelle_bank)."'";
					// if (mysqli_real_escape_string($link,$libelle_bank)=='OFF US Confrère'){echo "<br>".$sql;}
					// else{echo "<br> libelle_bank =============> ".$libelle_bank;}
					mysqli_query($link,"SET CHARACTER SET 'utf8'");
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0000000881 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0000000881 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_business_mode($libelle_bank)
{
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `business_mode` WHERE `libelle` = '".mysqli_real_escape_string($link,$libelle_bank)."'";
					// echo "<br>".$sql."<br>";
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0000000331 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0000000331 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_bank_csv_ktc($code_bank)
{
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `bank_name` WHERE `libelle_ktc` = '".mysqli_real_escape_string($link,$code_bank)."'";
		
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000001 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000001 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_bank_csv($code_bank)
{
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `bank_name` WHERE `code_bank` = '".mysqli_real_escape_string($link,$code_bank)."'";
		
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000001 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000001 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_bank_bkmvti_xls($libelle_bank)
{
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `bank_name` WHERE `libelle_bkmvti_xls` = '".mysqli_real_escape_string($link,$libelle_bank)."'";
					// echo $sql."<br>";
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000001 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000001 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_code_bank($libelle_bank)
{
					$link = ma_db_connexion();
					$sql = "SELECT  `id_auto`  FROM `bank_name` WHERE `libelle_xls` = '".mysqli_real_escape_string($link,$libelle_bank)."'";
					echo $sql."<br>";
				   $result=mysqli_query($link,$sql);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000001 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000001 !');
						}
					if(mysqli_num_rows($result)>0)
						{
							while ($row = mysqli_fetch_assoc($result)) 
								{	
									mysqli_close($link);			
									return  $row["id_auto"];
								}
						}
					else
						{
							mysqli_close($link);
							return '';
						}	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_processing_code($processing_code)
{	
					if($processing_code=='EC')
						{
							return 99;
						}
					else
						{
							return $processing_code;
						}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_courant_csv($date_courant)
{		
		list($date_courant,$heur_courant) = explode(' ', $date_courant);	
		list($jour,$mois,$annee) = explode('/', $date_courant);			
		return date('Y-m-d',mktime(date("H"), date('i'), date('s'), $mois,$jour,$annee));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get_date_courant($date_courant)
{	
		list($jour,$mois,$annee) = explode('/', $date_courant);			
		return date('Y-m-d',mktime(date("H"), date('i'), date('s'), $mois,$jour,$annee));
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_per_hour_global_in_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `stat_file_rejet_per_hour_gl` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000008 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000008 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `stat_file_rejet_per_hour_gl` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00000009 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00000009 !');
									}						
							}
					mysqli_close($link); 			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_per_hour_in_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `stat_file_rejet_per_hour` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000008 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000008 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `stat_file_rejet_per_hour` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00000009 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00000009 !');
									}						
							}
					mysqli_close($link); 			
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_transactionnelle_vers_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `activite_transactionnelle` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  000000773 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 000000773 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `activite_transactionnelle` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00000774 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00000774 !');
									}						
							}
					mysqli_close($link); 			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_nb_carte_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `nb_carte_gab_tpe` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
						  AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000003 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000003 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `nb_carte_gab_tpe` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
										 AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00000004 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00000004 !');
									}						
							}
					mysqli_close($link); 			
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_rejet_per_hour_vers_bdd($date_courant,
									 $date_autho,
									 $day_autho,
									 $nbr_autho,
									 $bank_name,
									 $nbr_tech_reject,
									 $percentage_tech_reject,
									 $h0,
									 $h1,
									 $h2,
									 $h3,
									 $h4,
									 $h5,
									 $h6,
									 $h7,
									 $h8,
									 $h9,
									 $h10,
									 $h11,
									 $h12,
									 $h13,
									 $h14,
									 $h15,
									 $h16,
									 $h17,
									 $h18,
									 $h19,
									 $h20,
									 $h21,
									 $h22,
									 $h23,
									 $user_create,
									 $date_create,
									 $user_modif,
									 $date_modif,$csv)
{
				  if(($csv==1)){	
				  
				  
				   delete_data_piece_joint_per_hour_in_vers_bdd($date_courant,$bank_name);
				   echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';
				   }
				   $link = ma_db_connexion();
				   // $sql1="SELECT  `id_auto`  FROM `cbs_stand_in` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
							// AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
				  
				   // $result=mysqli_query($link,$sql1);
 							// if (!$result)
								// {
										// error_log("Erreur sql hps membres vr bdd  00000010 : ".mysqli_error($link));
										// die('ERREUR QUERY carte_gab_tpe vr bdd 00000010 !');
								// }
				   
					// if (mysqli_num_rows($result) == 0)
								// { 
									$sql2 = "INSERT INTO  `stat_file_rejet_per_hour` (`id_auto`, `date_courant`, `date_autho`, `day_autho`, `nbr_autho`, `bank_name`, `nbr_tech_reject`, 
									`percentage_tech_reject`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `user_create`, `date_create`, `user_modif`, `date_modif`)
									VALUES (NULL,'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$date_autho)."',
									'".mysqli_real_escape_string($link,$day_autho)."','".mysqli_real_escape_string($link,$nbr_autho)."',
									'".mysqli_real_escape_string($link,$bank_name)."','".mysqli_real_escape_string($link,$nbr_tech_reject)."',
									'".mysqli_real_escape_string($link,$percentage_tech_reject)."','".mysqli_real_escape_string($link,$h0)."',
									'".mysqli_real_escape_string($link,$h1)."','".mysqli_real_escape_string($link,$h2)."',
									'".mysqli_real_escape_string($link,$h3)."','".mysqli_real_escape_string($link,$h4)."',
									'".mysqli_real_escape_string($link,$h5)."','".mysqli_real_escape_string($link,$h6)."',
									'".mysqli_real_escape_string($link,$h7)."','".mysqli_real_escape_string($link,$h8)."',
									'".mysqli_real_escape_string($link,$h9)."','".mysqli_real_escape_string($link,$h10)."',
									'".mysqli_real_escape_string($link,$h11)."','".mysqli_real_escape_string($link,$h12)."',
									'".mysqli_real_escape_string($link,$h13)."','".mysqli_real_escape_string($link,$h14)."',
									'".mysqli_real_escape_string($link,$h15)."','".mysqli_real_escape_string($link,$h16)."',
									'".mysqli_real_escape_string($link,$h17)."','".mysqli_real_escape_string($link,$h18)."',
									'".mysqli_real_escape_string($link,$h19)."','".mysqli_real_escape_string($link,$h20)."',
									'".mysqli_real_escape_string($link,$h21)."','".mysqli_real_escape_string($link,$h22)."',
									'".mysqli_real_escape_string($link,$h23)."','".mysqli_real_escape_string($link,$user_create)."',
									'".mysqli_real_escape_string($link,$date_create)."','".mysqli_real_escape_string($link,$user_modif)."',
									'".mysqli_real_escape_string($link,$date_modif)."')";
									// echo $sql2."<br>";
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps switch membre vr bdd  00000011 : ".mysqli_error($link));
															die('ERREUR QUERY hps switch membre vr bdd 00000011 !');
											}	
								// }
					mysqli_close($link); 					
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_activite_transactionnelle_vers_bdd($date_courant,$bank_name,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$LL,$M,$N,$AA,$csv)
{							// if(($AA==2)){ XLS
							if(($AA==2) || ($csv==1)){			
							delete_data_piece_joint_transactionnelle_vers_vers_bdd($date_courant,$bank_name);
							// echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';							
							}				  

				   
									$link = ma_db_connexion();

									$sql2 = "INSERT INTO  `activite_transactionnelle` (`id_auto`, `business_date`, `bank_name`, `business_mode`, 
									`authorisation_count`, `montant_transaction`, `processing_code`, `processing_code_warding`, `action_code`,
									`action_code_warding`, `percentage`, `reseau_us`, `reseau_master_card_visa`, `libelle_type_reseau`, `type_rejet`, `devise`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$bank_name)."',
									'".mysqli_real_escape_string($link,$C)."','".mysqli_real_escape_string($link,$D)."','".mysqli_real_escape_string($link,$E)."',
									'".mysqli_real_escape_string($link,$F)."','".mysqli_real_escape_string($link,$G)."','".mysqli_real_escape_string($link,$H)."',
									'".mysqli_real_escape_string($link,$I)."','".mysqli_real_escape_string($link,$J)."','".mysqli_real_escape_string($link,$K)."',
									'".mysqli_real_escape_string($link,$L)."','".mysqli_real_escape_string($link,$LL)."','".mysqli_real_escape_string($link,$M)."',
									'".mysqli_real_escape_string($link,$N)."')";
									// echo $sql2."<br>";
										mysqli_query($link,"SET CHARACTER SET 'utf8'");
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  00000006 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 00000006 !');
											}	

							mysqli_close($link); 					
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_nb_carte_vers_bdd($date_courant,$bank_name,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$O,$P,$Q,$R,$S,$T,$U,$V)
{
				  
				   delete_data_piece_joint_nb_carte_vers_bdd($date_courant,$bank_name);
				   
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `nb_carte_gab_tpe` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
							AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
				  
				   $result=mysqli_query($link,$sql1);
 							if (!$result)
								{
										error_log("Erreur sql hps membres vr bdd  00000005 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000005 !');
								}
				   
					if (mysqli_num_rows($result) == 0)
								{ 
									$sql2 = "INSERT INTO  `nb_carte_gab_tpe` (`id_auto`, `business_date`, `bank_name`, `new_atm_nbr`, `all_atm_nbr`, 
									`nb_atm_ktc`, `nb_atm_connectes_ktc`, `nb_atm_deconnectes_ktc`, `nb_atm_pwc`, `nb_new_atm_pwc`, `nb_atm_supprimes_pwc`, 
									`new_card_nbr`, `all_card_nbr`, `nb_cartes_activees_3_mois`, `nb_cartes_crees`, `nb_cartes_renouvelees`, 
									`nb_cartes_expirees`, `nb_cartes_annulees`, `nb_cartes_archivees`, `nb_cartes_creees_att_activations`, 
									`new_pos_nbr`, `all_pos_nbr`, `nb_tpe_config_modifiee`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$bank_name)."',
									'".mysqli_real_escape_string($link,$C)."','".mysqli_real_escape_string($link,$D)."','".mysqli_real_escape_string($link,$E)."',
									'".mysqli_real_escape_string($link,$F)."','".mysqli_real_escape_string($link,$G)."','".mysqli_real_escape_string($link,$H)."',
									'".mysqli_real_escape_string($link,$I)."','".mysqli_real_escape_string($link,$J)."','".mysqli_real_escape_string($link,$K)."',
									'".mysqli_real_escape_string($link,$L)."','".mysqli_real_escape_string($link,$M)."','".mysqli_real_escape_string($link,$N)."',
									'".mysqli_real_escape_string($link,$O)."','".mysqli_real_escape_string($link,$P)."','".mysqli_real_escape_string($link,$Q)."',
									'".mysqli_real_escape_string($link,$R)."','".mysqli_real_escape_string($link,$S)."','".mysqli_real_escape_string($link,$T)."',
									'".mysqli_real_escape_string($link,$U)."','".mysqli_real_escape_string($link,$V)."')";
									// echo $sql2."<br>";
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  00000006 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 00000006 !');
											}	
								}
					mysqli_close($link); 					
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_activite_transactionnelle_vers_bdd($fichier,$date_courant,$libelle)
 {
 echo ' <div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier XLS '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">';
	
			//$tmpfname = "test.xlsx";
		$url = $fichier;
		$filecontent = file_get_contents($url);
		$tmpfname = tempnam(sys_get_temp_dir(),"tmpxls");
		file_put_contents($tmpfname,$filecontent);
		
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		

		$boolGloblal=0;
		$AA=0;
		echo '<table class="table table-striped">';		
		for ($row = 1; $row <= $lastRow; $row++)		
		{
					if($worksheet->getCell('A'.$row)->getValue()=="BUSINESS_DATE")
					{
									echo '<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
					
									 echo '<tr>';			 
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>CODE_NAME</th>';
									 echo '<th>'.$worksheet->getCell('B'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('C'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('D'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('E'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('F'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('G'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('H'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('I'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('J'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('K'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('L'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('M'.$row)->getValue().'</th>';
									 echo '</tr>';
									 
							$boolGloblal=1;
					}
					if($boolGloblal==1) //Disponibilite
						{
						if(($worksheet->getCell('A'.$row)->getValue()<>"") )
							{	
							if($AA==1){ 
							}
							if($AA>1)	
								{	 
									 $business_date=get_date_courant(trim($worksheet->getCell('A'.$row)->getValue()));
									 $bank_name=get_code_bank(trim($worksheet->getCell('B'.$row)->getValue()));
									 $business_mode=get_business_mode(trim($worksheet->getCell('C'.$row)->getValue()));
									 $processing_code=get_processing_code(trim($worksheet->getCell('F'.$row)->getValue()));
									 $reseau_us=get_reseau_us(trim($worksheet->getCell('K'.$row)->getValue()));
									 echo '<tr>';			 
									 echo '<td>'.$business_date.'</td>';
									 echo '<td>'.$bank_name.'</td>';
									 echo '<td>'.$worksheet->getCell('B'.$row)->getValue().'</td>';
									 echo '<td>'.$business_mode.'</td>';
									 echo '<td>'.$worksheet->getCell('D'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('E'.$row)->getValue().'</td>';
									 echo '<td>'.$processing_code.'</td>';
									 echo '<td>'.$worksheet->getCell('G'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('H'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('I'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('J'.$row)->getValue().'</td>';
									 echo '<td>'.$reseau_us.'</td>';
									 echo '<td>'.$worksheet->getCell('L'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('M'.$row)->getValue().'</td>';						 
									 echo '</tr>';
										
										
									inserer_data_piece_joint_activite_transactionnelle_vers_bdd($business_date,
									$bank_name, 
									$business_mode, 
									$worksheet->getCell('D'.$row)->getValue(), 
									$worksheet->getCell('E'.$row)->getValue(), 
									$processing_code, 
									$worksheet->getCell('G'.$row)->getValue(), 
									$worksheet->getCell('H'.$row)->getValue(), 
									$worksheet->getCell('I'.$row)->getValue(), 
									$worksheet->getCell('J'.$row)->getValue(), 
									$reseau_us, 
									$reseau_us, 
									$worksheet->getCell('L'.$row)->getValue(), 
									$worksheet->getCell('M'.$row)->getValue(),$AA,1);									
								}
							$AA++;
							}
						else
							{
								$boolGloblal++;
							}
							
						}

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_nb_carte_vers_bdd($fichier,$date_courant,$libelle)
 {
 echo ' <div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier XLS '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">';
	
			//$tmpfname = "test.xlsx";
		$url = $fichier;
		$filecontent = file_get_contents($url);
		$tmpfname = tempnam(sys_get_temp_dir(),"tmpxls");
		file_put_contents($tmpfname,$filecontent);
		
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		

		$boolGloblal=0;
		$AA=0;
		echo '<table class="table table-striped">';		
		for ($row = 1; $row <= $lastRow; $row++)		
		{
					if($worksheet->getCell('A'.$row)->getValue()=="BUSINESS_DATE")
					{
									echo '<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									
									 echo '<tr>';			 
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>CODE_NAME</th>';
									 echo '<th>'.$worksheet->getCell('B'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('C'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('D'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('E'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('F'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('G'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('H'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('I'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('J'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('K'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('L'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('M'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('N'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('O'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('P'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('Q'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('R'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('S'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('T'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('U'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('V'.$row)->getValue().'</th>';
									 echo '</tr>';
									 
							$boolGloblal=1;
					}
					if($boolGloblal==1) //Disponibilite
						{
						if(($worksheet->getCell('A'.$row)->getValue()<>"") )
							{	
							if($AA==1){ 
								
							}
							if($AA>1)	
								{	
									 $business_date=get_date_courant(trim($worksheet->getCell('A'.$row)->getValue()));
									 $bank_name=get_code_bank(trim($worksheet->getCell('B'.$row)->getValue()));
									 echo '<tr>';			 
									 echo '<td>'.$business_date.'</td>';
									 echo '<td>'.$bank_name.'</td>';
									 echo '<td>'.$worksheet->getCell('B'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('C'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('D'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('E'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('F'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('G'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('H'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('I'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('J'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('K'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('L'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('M'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('N'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('O'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('P'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('Q'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('R'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('S'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('T'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('U'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('V'.$row)->getValue().'</td>';
									 
									 echo '</tr>';
													 
									inserer_data_piece_joint_nb_carte_vers_bdd($business_date,
									$bank_name, 
									$worksheet->getCell('C'.$row)->getValue(), 
									$worksheet->getCell('D'.$row)->getValue(), 
									$worksheet->getCell('E'.$row)->getValue(), 
									$worksheet->getCell('F'.$row)->getValue(), 
									$worksheet->getCell('G'.$row)->getValue(), 
									$worksheet->getCell('H'.$row)->getValue(), 
									$worksheet->getCell('I'.$row)->getValue(), 
									$worksheet->getCell('J'.$row)->getValue(), 
									$worksheet->getCell('K'.$row)->getValue(), 
									$worksheet->getCell('L'.$row)->getValue(), 
									$worksheet->getCell('M'.$row)->getValue(), 
									$worksheet->getCell('N'.$row)->getValue(), 
									$worksheet->getCell('O'.$row)->getValue(), 
									$worksheet->getCell('P'.$row)->getValue(), 
									$worksheet->getCell('Q'.$row)->getValue(), 
									$worksheet->getCell('R'.$row)->getValue(), 
									$worksheet->getCell('S'.$row)->getValue(), 
									$worksheet->getCell('T'.$row)->getValue(), 
									$worksheet->getCell('U'.$row)->getValue(), 
									$worksheet->getCell('V'.$row)->getValue());									
								}
							$AA++;
							}
						else
							{
								$boolGloblal++;
							}
							
						}

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }	
 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_taux_dispo_srv_gab_tpe_vers_vers_bdd($date_courant,$bank_name,$type)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`,`taux_dispo_gab` ,`taux_dispo_tpe`   FROM `taux_dispo_srv_gab_tpe` 
				   WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
				   AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."' AND  `taux_dispo_gab` <> 0 AND  `taux_dispo_tpe` <> 0";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0045254454500773 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0045254454500773 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{
						while ($row = mysqli_fetch_assoc($result)) 
								{									
									if (($type=='GAB') && ($row["taux_dispo_tpe"]<>0))
										{
											$sql2 = "UPDATE `taux_dispo_srv_gab_tpe` SET `taux_dispo_gab` = 0  
													WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
													AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."' ";
											$result2=mysqli_query($link,$sql2);
																		if (!$result2)
																				{
																					error_log("Erreur sql ABTPE 108880050 : ".mysqli_error($link));
																					die('ERREUR QUERY ABTPE 108880050 !');
																				}										
										}
									if (($type=='TPE') && ($row["taux_dispo_gab"]<>0))
										{
											$sql2 = "UPDATE `taux_dispo_srv_gab_tpe` SET `taux_dispo_tpe` = 0
													WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
													AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."' ";
											$result2=mysqli_query($link,$sql2);
																		if (!$result2)
																				{
																					error_log("Erreur sql ABTPE 108880050 : ".mysqli_error($link));
																					die('ERREUR QUERY ABTPE 108880050 !');
																				}										
										}
									if (($row["taux_dispo_gab"]==0) && ($row["taux_dispo_tpe"]==0))	
										{
											$sql2 = "DELETE FROM `taux_dispo_srv_gab_tpe` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
											AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."'";
													 // echo $sql2;
											$result2=mysqli_query($link,$sql2);
											if (!$result2)
												{
																error_log("Erreur sql hps membres vr bdd  085656000774 : ".mysqli_error($link));
																die('ERREUR QUERY carte_gab_tpe vr bdd 085656000774 !');
												}										
										}								
								}
							}
					mysqli_close($link); 			
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_taux_dispo_srv_gab_tpe_vers_bdd($date_courant,$bank_name,$taux_dispo,$AA,$type)
{							// if(($AA==2)){ XLS
							if(($AA==2)){			
							delete_data_piece_joint_taux_dispo_srv_gab_tpe_vers_vers_bdd($date_courant,$bank_name,$type);
							// echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';							
							}				  
				   
								$link = ma_db_connexion();
													
								$sql1="SELECT  `id_auto`,`taux_dispo_gab` ,`taux_dispo_tpe`   FROM `taux_dispo_srv_gab_tpe` 
								WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
								AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."' 
								AND (`taux_dispo_gab` <> 0 OR `taux_dispo_tpe` <> 0) ";	
								// echo $sql1."<br>";								
								$result=mysqli_query($link,$sql1);
								if (!$result)
									{
													error_log("Erreur sql hps membres vr bdd  004525448788854500773 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 004525448788854500773 !');
									}
				   
								if (mysqli_num_rows($result)>0)
									{
										if ($type=='GAB')
											{
												$sql2 = "UPDATE `taux_dispo_srv_gab_tpe` SET `taux_dispo_gab` = '".mysqli_real_escape_string($link,$taux_dispo)."' 
														WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
														AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."' ";
												// echo $sql2."<br>";			
												$result2=mysqli_query($link,$sql2);
																			if (!$result2)
																					{
																						error_log("Erreur sql ABTPE 10884444480050 : ".mysqli_error($link));
																						die('ERREUR QUERY ABTPE 10884444480050 !');
																					}										
											}
										 if ($type=='TPE')
											{
												$sql2 = "UPDATE `taux_dispo_srv_gab_tpe` SET `taux_dispo_tpe` = '".mysqli_real_escape_string($link,$taux_dispo)."' 
														WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
														AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."' ";
												// echo $sql2."<br>";	
												$result2=mysqli_query($link,$sql2);
																			if (!$result2)
																					{
																						error_log("Erreur sql ABTPE 1088564564480050 : ".mysqli_error($link));
																						die('ERREUR QUERY ABTPE 1088564564480050 !');
																					}										
											}
									
								
									}										
								else  
									{
										
										if ($type=='GAB')
											{									
											$sql2 = "INSERT INTO  `taux_dispo_srv_gab_tpe` (`id_auto`, `code_bank`, `date_courant`, `taux_dispo_gab`)
											VALUES ( NULL,'".mysqli_real_escape_string($link,$bank_name)."','".mysqli_real_escape_string($link,$date_courant)."',
											'".mysqli_real_escape_string($link,$taux_dispo)."' )";
											echo $sql2."<br>";
												$result2=mysqli_query($link,$sql2);
												if (!$result2)
													{
																	error_log("Erreur sql hps membres vr bdd  0000878989890006 : ".mysqli_error($link));
																	die('ERREUR QUERY carte_gab_tpe vr bdd 0000878989890006 !');
													}
											}
										if ($type=='TPE')
											{
												$sql2 = "INSERT INTO  `taux_dispo_srv_gab_tpe` (`id_auto`, `code_bank`, `date_courant`,`taux_dispo_tpe`)
												VALUES ( NULL,'".mysqli_real_escape_string($link,$bank_name)."','".mysqli_real_escape_string($link,$date_courant)."',
												'".mysqli_real_escape_string($link,$taux_dispo)."' )";
												echo $sql2."<br>";
													$result2=mysqli_query($link,$sql2);
													if (!$result2)
														{
																		error_log("Erreur sql hps membres vr bdd  08877488748740000006 : ".mysqli_error($link));
																		die('ERREUR QUERY carte_gab_tpe vr bdd 08877488748740000006 !');
														}												
											}										
									}												
											
											
											
							mysqli_close($link); 					
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_heure_envoi_bkmvti_vers_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `heure_envoi_bkmvti` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
				   AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0000875500773 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0000875500773 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `heure_envoi_bkmvti` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
								AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00755000774 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00755000774 !');
									}						
							}
					mysqli_close($link); 			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_heure_envoi_bkmvti_vers_bdd($date_courant,$bank_name,$B,$C,$AA,$csv)
{							// if(($AA==2)){ XLS
							if(($AA==2) || ($csv==1)){			
							delete_data_piece_joint_heure_envoi_bkmvti_vers_vers_bdd($date_courant,$bank_name);
							// echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';							
							}				  

				   
									$link = ma_db_connexion();

									$sql2 = "INSERT INTO  `heure_envoi_bkmvti` (`id_auto`, `code_bank`, `date_courant`, `heure_envoi`, `heure_sla`, `etat`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$bank_name)."','".mysqli_real_escape_string($link,$date_courant)."',
									'".mysqli_real_escape_string($link,$B)."','".mysqli_real_escape_string($link,$C)."',1)";
									// echo $sql2."<br>";
										mysqli_query($link,"SET CHARACTER SET 'utf8'");
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  00000006 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 00000006 !');
											}	

							mysqli_close($link); 					
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_taux_dispo_parc_gab_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `availability_avg_gab` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
				   AND `filiale` = '".mysqli_real_escape_string($link,$bank_name)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  000087555555500775575743 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 000087555555500775575743 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `availability_avg_gab` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
								AND `filiale` = '".mysqli_real_escape_string($link,$bank_name)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00755054564078780774 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00755054564078780774 !');
									}						
							}
					mysqli_close($link); 			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_taux_dispo_parc_gab_vers_bdd($date_courant,$bank_name,$O)
{							// if(($AA==2)){ XLS
							// if(($AA==1))
							{			
							delete_data_piece_joint_taux_dispo_parc_gab_vers_bdd($date_courant,$bank_name);
							// echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';							
							}				  

				   
									$link = ma_db_connexion();

									$sql2 = "INSERT INTO  `availability_avg_gab` (`id_auto`, `filiale`, `date_courant`, `taux_dispo`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$bank_name)."',
									'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$O)."')";
									// echo $sql2."<br>";
										mysqli_query($link,"SET CHARACTER SET 'utf8'");
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  00444555000006 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 00444555000006 !');
											}	

							mysqli_close($link); 					
} 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_taux_dispo_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `taux_dispo_gab` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
				   AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0000875500775575743 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0000875500775575743 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `taux_dispo_gab` WHERE `date_courant` = '".mysqli_real_escape_string($link,$date_courant)."'
								AND `code_bank` = '".mysqli_real_escape_string($link,$bank_name)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  007550078780774 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 007550078780774 !');
									}						
							}
					mysqli_close($link); 			
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_taux_dispo_vers_bdd($date_courant,$bank_name,$AA,$A,$C,$O)
{							// if(($AA==2)){ XLS
							if(($AA==1)){			
							delete_data_piece_joint_taux_dispo_vers_bdd($date_courant,$bank_name);
							// echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';							
							}				  

				   
									$link = ma_db_connexion();

									$sql2 = "INSERT INTO  `taux_dispo_gab` (`id_auto`, `code_bank`, `date_courant`, `atm_name`, 
									`acronym`,  `availability`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$bank_name)."','".mysqli_real_escape_string($link,$date_courant)."',
									'".mysqli_real_escape_string($link,$A)."',
									'".mysqli_real_escape_string($link,$C)."','".mysqli_real_escape_string($link,$O)."')";
									// echo $sql2."<br>";
										mysqli_query($link,"SET CHARACTER SET 'utf8'");
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  00444000006 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 00444000006 !');
											}	

							mysqli_close($link); 					
} 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_atm_vers_bdd($fichier,$date_courant,$libelle,$bank_name)
 {
	 // $bank_name=8;
 echo ' <div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier XLS '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">';
	
			//$tmpfname = "test.xlsx";
		$url = $fichier;
		$filecontent = file_get_contents($url);
		$tmpfname = tempnam(sys_get_temp_dir(),"tmpxls");
		file_put_contents($tmpfname,$filecontent);
		
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		

		$boolGloblal=0;
		$boolTaux=0;
		$AA=0;
		echo '<table class="table table-striped">';		
		for ($row = 1; $row <= $lastRow; $row++)		
		{
					if($worksheet->getCell('A'.$row)->getValue()=="ATM Name")
					{
									echo '<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									
									 echo '<tr>';			 
									 echo '<th>#</th>';
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('C'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('D'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('E'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('G'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('I'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('J'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('K'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('L'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('M'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('N'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('O'.$row)->getValue().'</th>';
									 echo '</tr>';
									 
							$boolGloblal=1;
					}
					if($boolGloblal==1) //ATM Name
						{
						if(($worksheet->getCell('A'.$row)->getValue()<>"") )
							{	
							if($AA>=1)	
								{	
									// if(($AA<=8)&&($AA>=1))
									{

									 echo '<tr>';			 
									 echo '<td>'.$AA.'</td>';
									 echo '<td>'.$worksheet->getCell('A'.$row)->getValue().'</td>';
									 echo '<td>CC'.$worksheet->getCell('C'.$row)->getValue().'</td>'; 
									 echo '<td>DD'.$worksheet->getCell('D'.$row)->getValue().'</td>';
									 echo '<td>EE'.$worksheet->getCell('E'.$row)->getValue().'</td>';
									 echo '<td>GG'.$worksheet->getCell('G'.$row)->getValue().'</td>';
									 echo '<td>II'.$worksheet->getCell('I'.$row)->getValue().'</td>';
									 echo '<td>JJ'.$worksheet->getCell('J'.$row)->getValue().'</td>';
									 echo '<td>KK'.$worksheet->getCell('K'.$row)->getValue().'</td>';
									 echo '<td>LL'.$worksheet->getCell('L'.$row)->getValue().'</td>';
									 echo '<td>MM'.$worksheet->getCell('M'.$row)->getValue().'</td>';
									 echo '<td>NN'.$worksheet->getCell('N'.$row)->getValue().'</td>';
									 echo '<td>OO'.$worksheet->getCell('O'.$row)->getValue().'</td>';
									 echo '</tr>';
									 
									inserer_data_piece_joint_taux_dispo_vers_bdd($date_courant,
									$bank_name,$AA,$worksheet->getCell('A'.$row)->getValue(),$worksheet->getCell('C'.$row)->getValue(),$worksheet->getCell('O'.$row)->getValue());	
									
									}
									
								}
							$AA++;
							}
						else
							{
								$boolGloblal++;
							}
							
							
							
						}
						
							if($boolTaux==0) //ATM Name
						{				
							if($worksheet->getCell('A'.$row)->getValue()=="Averages")
							{
											echo '<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
											
											 echo '<tr>';			 
											 echo '<th>'.$worksheet->getCell('L'.$row)->getValue().'</th>';	
											 echo '</tr>';
									inserer_data_piece_joint_taux_dispo_parc_gab_vers_bdd($date_courant,$bank_name,$worksheet->getCell('O'.$row)->getValue());		 
											 
									$boolTaux++;
							}
						}					
						

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_bkmvti_vers_bdd($fichier,$date_courant,$libelle)
 {
 echo ' <div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier XLS '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">';
	
			//$tmpfname = "test.xlsx";
		$url = $fichier;
		$filecontent = file_get_contents($url);
		$tmpfname = tempnam(sys_get_temp_dir(),"tmpxls");
		file_put_contents($tmpfname,$filecontent);
		
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		

		$boolGloblal=0;
		$AA=0;
		echo '<table class="table table-striped">';		
		for ($row = 1; $row <= $lastRow; $row++)		
		{
					if($worksheet->getCell('A'.$row)->getValue()=="BANK_NAME")
					{
									echo '<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									
									 echo '<tr>';			 
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('B'.$row, 'Date/time value:')->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('C'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('D'.$row)->getValue().'</th>';
									 echo '</tr>';
									 
							$boolGloblal=1;
					}
					if($boolGloblal==1) //Disponibilite
						{
						if(($worksheet->getCell('A'.$row)->getValue()<>"") )
							{	
							if($AA==1){}
							if($AA>=1)	
								{	
									if(($AA<=12)&&($AA>=1))
									{
									 // $business_date=get_date_courant(trim($worksheet->getCell('A'.$row)->getValue()));
									 $bank_name=get_code_bank_bkmvti_xls(trim($worksheet->getCell('A'.$row)->getValue()));
									 echo '<tr>';			 
									 echo '<td>'.$AA.'</td>';
									 echo '<td>'.$bank_name.'</td>';
									 echo '<td>'.$worksheet->getCell('A'.$row)->getValue().'</td>';
									 echo '<td>';echo $worksheet->getCell('B'.$row)->getFormattedValue();
									 echo '</td>'; 
									 echo '<td>'.$worksheet->getCell('C'.$row)->getValue().'</td>';
									 echo '</tr>';
									 
									inserer_data_piece_joint_heure_envoi_bkmvti_vers_bdd($date_courant,
									$bank_name,$worksheet->getCell('B'.$row)->getFormattedValue(),$worksheet->getCell('C'.$row)->getValue(),2,0);	
									
									}
									
									if(($AA<=21)&&($AA>=14))
									{
									 $bank_name=get_code_bank_bkmvti_xls(trim($worksheet->getCell('A'.$row)->getValue()));
									 echo '<tr>';			 
									 echo '<td>'.$AA.'</td>';
									 echo '<td>'.$bank_name.'</td>';
									 echo '<td>'.$worksheet->getCell('A'.$row)->getValue().'</td>';
									 $taux_dispo_gab=$worksheet->getCell('B'.$row)->getValue()*100;
									 echo '<td>'.$taux_dispo_gab.'</td>';
									 $taux_disponibilite_gab=round((100-$taux_dispo_gab),2);
									 echo '<td>'.$worksheet->getCell('C'.$row)->getValue().'</td>';
									 echo '<td>'.$taux_disponibilite_gab.'</td>';
									 echo '</tr>';
									inserer_data_piece_joint_taux_dispo_srv_gab_tpe_vers_bdd($date_courant,
									$bank_name,$taux_dispo_gab,$AA,'GAB');																	
									}
									if(($AA<=38)&&($AA>=22))
									{
									 $bank_name=get_code_bank_bkmvti_xls(trim($worksheet->getCell('A'.$row)->getValue()));
									 
									if(TRIM($worksheet->getCell('A'.$row)->getValue())<>"BANK_NAME")
										{								 
											 echo '<tr>';			 
											 echo '<td>'.$AA.'</td>';
											 echo '<td>'.$bank_name.'</td>';
											 echo '<td>'.$worksheet->getCell('A'.$row)->getValue().'</td>';
											 $taux_tpe=$worksheet->getCell('B'.$row)->getValue()*100;
											 echo '<td>'.$taux_tpe.'</td>';
											 $taux_disponibilite_tpe=round((100-$taux_tpe),2);
											 echo '<td>'.$worksheet->getCell('C'.$row)->getValue().'</td>';
											 echo '<td>'.$taux_disponibilite_tpe.'</td>';
											 echo '</tr>';
											 
											inserer_data_piece_joint_taux_dispo_srv_gab_tpe_vers_bdd($date_courant,
											$bank_name,$taux_tpe,$AA,'TPE');	
										}

									
									// inserer_data_piece_joint_nb_carte_vers_bdd($business_date,
									// $bank_name, 
									// $worksheet->getCell('C'.$row)->getValue());																		
									}									
								}
							$AA++;
							}
						else
							{
								$boolGloblal++;
							}
							
						}

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verif_action_code_warding($action_code,$action_code_warding)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `action_code_wording` WHERE `id_auto` = '".mysqli_real_escape_string($link,$action_code)."'";	
					// echo "<br>".$sql1;				   
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  000087700773 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 000087700773 !');
						}
				   
					if (mysqli_num_rows($result)==0)
							{ 
								$sql2 = "INSERT INTO  `action_code_wording` (`id_auto`, `libelle`, `libelle_fr`)
									VALUES ('".mysqli_real_escape_string($link,$action_code)."',
									'".mysqli_real_escape_string($link,$action_code_warding)."',
									'".mysqli_real_escape_string($link,$action_code_warding)."')";
										 // echo "<br>".$sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  0008700774 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 0008700774 !');
									}						
							}
					mysqli_close($link); 	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function verif_type_carte($reseau_us,$reseau_master_card_visa)
 {
	if(($reseau_us=='3')&&($reseau_master_card_visa=='1'))
		{
				return 14;
		}	
	else
		{
				return $reseau_master_card_visa;
		}
 }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_csv_file_banks_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=60  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>bank_code</th>';
									 echo '<th>category</th>';
									 echo '<th>center_code</th>';
									 echo '<th>bank_name</th>';
									 echo '<th>abrev_name</th>';
									 echo '<th>address_1</th>';
									 echo '<th>city_code</th>';
									 echo '<th>zip_code</th>';
									 echo '<th>region_code</th>';
									 echo '<th>country_code</th>';
									 echo '<th>phone_1</th>';
									 echo '<th>phone_2</th>';
									 echo '<th>fax_number</th>';
									 echo '<th>email</th>';
									 echo '<th>web_url</th>';
									 echo '<th>bank_member_ind</th>';
									 echo '<th>checking_account_ind</th>';
									 echo '<th>transmission_mode</th>';
									 echo '<th>multi_country_ind</th>';
									 echo '<th>public_bank_id</th>';
									 echo '<th>contact_name</th>';
									 echo '<th>contact_phone</th>';
									 echo '<th>vat</th>';
									 echo '<th>eff_date_vat</th>';
									 echo '<th>former_vat</th>';
									 echo '<th>interest_vat</th>';
									 echo '<th>interest_eff_date_vat</th>';
									 echo '<th>interest_former_vat</th>';
									 echo '<th>fund</th>';
									 echo '<th>eff_date_fund</th>';
									 echo '<th>former_fund</th>';
									 echo '<th>bank_currency_code</th>';
									 echo '<th>zip_code_option</th>';
									 echo '<th>ctrl_client_len</th>';
									 echo '<th>ctrl_client_key</th>';
									 echo '<th>ctrl_shadow_account_len</th>';
									 echo '<th>ctrl_shadow_account_key</th>';
									 echo '<th>ctrl_account_len</th>';
									 echo '<th>ctrl_account_key</th>';
									 echo '<th>ctrl_chain_len</th>';
									 echo '<th>ctrl_chain_key</th>';
									 echo '<th>ctrl_merchant_len</th>';
									 echo '<th>ctrl_merchant_key</th>';
									 echo '<th>ctrl_outlet_len</th>';
									 echo '<th>ctrl_outlet_key</th>';
									 echo '<th>renew_print_delay</th>';
									 echo '<th>delivery_default</th>';
									 echo '<th>daily_autho_number_alert</th>';
									 echo '<th>account_number</th>';
									 echo '<th>key_account</th>';
									 echo '<th>status</th>';
									 echo '<th>status_date</th>';
									 echo '<th>user_create</th>';
									 echo '<th>date_create</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
				
				
				
				
													
				
				
					$chaine = explode(",", $tabfich[$i]);
					
					$bank_code=str_replace('"', '', $chaine[0]);					
					// $business_date=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));
					$category=str_replace('"', '', $chaine[1]);
					$center_code=str_replace('"', '', $chaine[2]);
					$bank_name=str_replace('"', '', $chaine[3]);
					$abrev_name=str_replace('"', '', $chaine[4]);
					$address_1=str_replace('"', '', $chaine[5]);
					$city_code=str_replace('"', '', $chaine[9]);
					$zip_code=str_replace('"', '', $chaine[10]);
					$region_code=str_replace('"', '', $chaine[11]);
					$country_code=str_replace('"', '', $chaine[12]);
					$phone_1=str_replace('"', '', $chaine[13]);
					$phone_2=str_replace('"', '', $chaine[14]);
					$fax_number=str_replace('"', '', $chaine[15]);
					$email=str_replace('"', '', $chaine[16]);
					$web_url=str_replace('"', '', $chaine[17]);
					$bank_member_ind=str_replace('"', '', $chaine[18]);
					$checking_account_ind=str_replace('"', '', $chaine[19]);
					$transmission_mode=str_replace('"', '', $chaine[20]);
					$multi_country_ind=str_replace('"', '', $chaine[21]);
					$public_bank_id=str_replace('"', '', $chaine[22]);
					$contact_name=str_replace('"', '', $chaine[23]);
					$contact_phone=str_replace('"', '', $chaine[24]);
					$vat=str_replace('"', '', $chaine[25]);
					$eff_date_vat=str_replace('"', '', $chaine[26]);
					$former_vat=str_replace('"', '', $chaine[27]);
					$interest_vat=str_replace('"', '', $chaine[28]);
					$interest_eff_date_vat=str_replace('"', '', $chaine[29]);
					$interest_former_vat=str_replace('"', '', $chaine[30]);
					$fund=str_replace('"', '', $chaine[31]);
					$eff_date_fund=str_replace('"', '', $chaine[32]);
					$former_fund=str_replace('"', '', $chaine[33]);
					$bank_currency_code=str_replace('"', '', $chaine[34]);
					$zip_code_option=str_replace('"', '', $chaine[35]);
					$ctrl_client_len=str_replace('"', '', $chaine[36]);
					$ctrl_client_key=str_replace('"', '', $chaine[37]);
					$ctrl_shadow_account_len=str_replace('"', '', $chaine[38]);
					$ctrl_shadow_account_key=str_replace('"', '', $chaine[39]);
					$ctrl_account_len=str_replace('"', '', $chaine[40]);
					$ctrl_account_key=str_replace('"', '', $chaine[41]);
					$ctrl_chain_len=str_replace('"', '', $chaine[42]);
					$ctrl_chain_key=str_replace('"', '', $chaine[43]);
					$ctrl_merchant_len=str_replace('"', '', $chaine[44]);
					$ctrl_merchant_key=str_replace('"', '', $chaine[45]);
					$ctrl_outlet_len=str_replace('"', '', $chaine[46]);
					$ctrl_outlet_key=str_replace('"', '', $chaine[47]);
					$renew_print_delay=str_replace('"', '', $chaine[48]);
					$delivery_default=str_replace('"', '', $chaine[49]);
					$daily_autho_number_alert=str_replace('"', '', $chaine[50]);
					$account_number=str_replace('"', '', $chaine[51]);
					$key_account=str_replace('"', '', $chaine[52]);
					$status=str_replace('"', '', $chaine[53]);
					$status_date=str_replace('"', '', $chaine[54]);
					$user_create=str_replace('"', '', $chaine[70]);
					$date_create=str_replace('"', '', $chaine[71]);

									 echo '<tr>';			 
									  echo '<th>'.$bank_code.'</th>';
									  echo '<th>'.$category.'</th>';
									  echo '<th>'.$center_code.'</th>';
									  echo '<th>'.$bank_name.'</th>';
									  echo '<th>'.$abrev_name.'</th>';
									  echo '<th>'.$address_1.'</th>';
									  echo '<th>'.$city_code.'</th>';
									  echo '<th>'.$zip_code.'</th>';
									  echo '<th>'.$region_code.'</th>';
									  echo '<th>'.$country_code.'</th>';
									  echo '<th>'.$phone_1.'</th>';
									  echo '<th>'.$phone_2.'</th>';
									  echo '<th>'.$fax_number.'</th>';
									  echo '<th>'.$email.'</th>';
									  echo '<th>'.$web_url.'</th>';
									  echo '<th>'.$bank_member_ind.'</th>';
									  echo '<th>'.$checking_account_ind.'</th>';
									  echo '<th>'.$transmission_mode.'</th>';
									  echo '<th>'.$multi_country_ind.'</th>';
									  echo '<th>'.$public_bank_id.'</th>';
									  echo '<th>'.$contact_name.'</th>';
									  echo '<th>'.$contact_phone.'</th>';
									  echo '<th>'.$vat.'</th>';
									  echo '<th>'.$eff_date_vat.'</th>';
									  echo '<th>'.$former_vat.'</th>';
									  echo '<th>'.$interest_vat.'</th>';
									  echo '<th>'.$interest_eff_date_vat.'</th>';
									  echo '<th>'.$interest_former_vat.'</th>';
									  echo '<th>'.$fund.'</th>';
									  echo '<th>'.$eff_date_fund.'</th>';
									  echo '<th>'.$former_fund.'</th>';
									  echo '<th>'.$bank_currency_code.'</th>';
									  echo '<th>'.$zip_code_option.'</th>';
									  echo '<th>'.$ctrl_client_len.'</th>';
									  echo '<th>'.$ctrl_client_key.'</th>';
									  echo '<th>'.$ctrl_shadow_account_len.'</th>';
									  echo '<th>'.$ctrl_shadow_account_key.'</th>';
									  echo '<th>'.$ctrl_account_len.'</th>';
									  echo '<th>'.$ctrl_account_key.'</th>';
									  echo '<th>'.$ctrl_chain_len.'</th>';
									  echo '<th>'.$ctrl_chain_key.'</th>';
									  echo '<th>'.$ctrl_merchant_len.'</th>';
									  echo '<th>'.$ctrl_merchant_key.'</th>';
									  echo '<th>'.$ctrl_outlet_len.'</th>';
									  echo '<th>'.$ctrl_outlet_key.'</th>';
									  echo '<th>'.$renew_print_delay.'</th>';
									  echo '<th>'.$delivery_default.'</th>';
									  echo '<th>'.$daily_autho_number_alert.'</th>';
									  echo '<th>'.$account_number.'</th>';
									  echo '<th>'.$key_account.'</th>';
									  echo '<th>'.$status.'</th>';
									  echo '<th>'.$status_date.'</th>';
									  echo '<th>'.$user_create.'</th>';
									  echo '<th>'.$date_create.'</th>';
									 echo '</tr>';					

										
											// verif_action_code_warding($action_code,$action_code_warding);
											// inserer_data_piece_joint_activite_transactionnelle_vers_bdd($business_date,
												// $bank_code,	
												// $category,	
												// $center_code,	
												// $bank_name,	
												// $abrev_name,	
												// $address_1,	
												// $city_code,	
												// $zip_code,	
												// $region_code,	
												// $country_code,	
												// $phone_1,	
												// $phone_2,	
												// $fax_number,	
												// $email,	
												// $web_url,	
												// $bank_member_ind,	
												// $checking_account_ind,	
												// $transmission_mode,	
												// $multi_country_ind,	
												// $public_bank_id,	
												// $contact_name,	
												// $contact_phone,	
												// $vat,	
												// $eff_date_vat,	
												// $former_vat,	
												// $interest_vat,	
												// $interest_eff_date_vat,	
												// $interest_former_vat,	
												// $fund,	
												// $eff_date_fund,	
												// $former_fund,	
												// $bank_currency_code,	
												// $zip_code_option,	
												// $ctrl_client_len,	
												// $ctrl_client_key,	
												// $ctrl_shadow_account_len,	
												// $ctrl_shadow_account_key,	
												// $ctrl_account_len,	
												// $ctrl_account_key,	
												// $ctrl_chain_len,	
												// $ctrl_chain_key,	
												// $ctrl_merchant_len,	
												// $ctrl_merchant_key,	
												// $ctrl_outlet_len,	
												// $ctrl_outlet_key,	
												// $renew_print_delay,	
												// $delivery_default,	
												// $daily_autho_number_alert,	
												// $account_number,	
												// $key_account,	
												// $status,	
												// $status_date,
												// $user_create,	
												// $date_create,0,$i);	
																					
										
	

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_tpe_activestivity_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `list_tpe_activestivity` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00005550008 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00005550008 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `list_tpe_activestivity` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  000055500089 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 000055500089 !');
									}						
							}
					mysqli_close($link); 			
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_tpe_absence_de_telecollecte_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `list_tlc_echouestivity` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  555558452 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 555558452 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `list_tlc_echouestivity` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  0045800089 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 0045800089 !');
									}						
							}
					mysqli_close($link); 			
}
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_file_dispo_vers_bdd($date_courant,$bank_name,$C,$D,$E,$F,$G,$AA,$csv)
{
				  if(($AA==2) || ($csv==1)){	
				   delete_data_piece_joint_tpe_absence_de_telecollecte_vers_bdd($date_courant,$bank_name);
				   // echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';
				   }
				   $link = ma_db_connexion();
				   // $sql1="SELECT  `id_auto`  FROM `cbs_stand_in` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
							// AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
				  
				   // $result=mysqli_query($link,$sql1);
 							// if (!$result)
								// {
										// error_log("Erreur sql hps membres vr bdd  00000010 : ".mysqli_error($link));
										// die('ERREUR QUERY carte_gab_tpe vr bdd 00000010 !');
								// }
				   
					// if (mysqli_num_rows($result) == 0)
								// { 
									$sql2 = "INSERT INTO  `list_tlc_echouestivity` (`id_auto`, `business_date`, `bank_name`,
									`id_terminal`, `statut`, `nbr_transaction`, `montant`, `date_tcl`, `date_prise_charge`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$bank_name)."',
									'".mysqli_real_escape_string($link,$C)."','".mysqli_real_escape_string($link,$D)."','".mysqli_real_escape_string($link,$E)."',
									'".mysqli_real_escape_string($link,$F)."','".mysqli_real_escape_string($link,substr($G, 0, -1))."',NOW())";
									// echo $sql2."<br>";
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  008770011 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 008770011 !');
											}	
								// }
					mysqli_close($link); 					
}
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_joint_file_rejet_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=7  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>sequence_number</th>';
									 echo '<th>bank_code</th>';
									 echo '<th>activity_date</th>';
									 echo '<th>buffer_2</th>';
									 echo '<th>buffer_3</th>';
									 echo '<th>buffer_4</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$chaine = explode(",", $tabfich[$i]);	
									$BUSINESS_DATE='';
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									// echo $chaine[1]."<br>";
									$sequence_number=(trim(str_replace('"', '', $chaine[0])));	
									$buffer = explode(",", (trim(str_replace('"', '', $chaine[1]))));
									$bank_code=(trim(str_replace('"', '', $buffer[0])));	
									$activity_date=(trim(str_replace('"', '', $buffer[1])));	
									$buffer_2=(trim(str_replace('"', '', $buffer[2])));	
									$buffer_3=(trim(str_replace('"', '', $buffer[3])));	
									$buffer_4=(trim(str_replace('"', '', $buffer[4])));	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$sequence_number.'</th>';
									 echo '<th>'.$bank_code.'</th>';
									 echo '<th>'.$activity_date.'</th>';
									 echo '<th>'.$buffer_2.'</th>';
									 echo '<th>'.$buffer_3.'</th>';
									 echo '<th>'.$buffer_4.'</th>';
								 echo '</tr>';						
					


									// inserer_data_piece_joint_file_rejet_vers_bdd($BUSINESS_DATE,	
									// $sequence_number,	
									// $bank_code,	
									// $date_create,	
									// $date_start,	
									// $date_end,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_joint_file_timet_per_hour_global_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=8  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>sequence_number</th>';
									 echo '<th>bank_code</th>';
									 echo '<th>activity_date</th>';
									 echo '<th>buffer_2</th>';
									 echo '<th>buffer_3</th>';
									 echo '<th>buffer_4</th>';
									 echo '<th>buffer_5</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$chaine = explode(",", $tabfich[$i]);	
									$BUSINESS_DATE='';
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									// echo $chaine[1]."<br>";
									$sequence_number=(trim(str_replace('"', '', $chaine[0])));	
									$buffer = explode(",", (trim(str_replace('"', '', $chaine[1]))));
									$bank_code=(trim(str_replace('"', '', $buffer[0])));	
									$activity_date=(trim(str_replace('"', '', $buffer[1])));	
									$buffer_2=(trim(str_replace('"', '', $buffer[2])));	
									$buffer_3=(trim(str_replace('"', '', $buffer[3])));	
									$buffer_4=(trim(str_replace('"', '', $buffer[4])));	
									$buffer_5=(trim(str_replace('"', '', $buffer[5])));	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$sequence_number.'</th>';
									 echo '<th>'.$bank_code.'</th>';
									 echo '<th>'.$activity_date.'</th>';
									 echo '<th>'.$buffer_2.'</th>';
									 echo '<th>'.$buffer_3.'</th>';
									 echo '<th>'.$buffer_4.'</th>';
									 echo '<th>'.$buffer_5.'</th>';
								 echo '</tr>';						
					


									// inserer_data_piece_joint_file_timet_per_hour_global_vers_bdd($BUSINESS_DATE,	
									// $sequence_number,	
									// $bank_code,	
									// $date_create,	
									// $date_start,	
									// $date_end,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_joint_file_picko_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=6  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>sequence_number</th>';
									 echo '<th>bank_code</th>';
									 echo '<th>activity_date</th>';
									 echo '<th>buffer_2</th>';
									 echo '<th>buffer_3</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$chaine = explode(",", $tabfich[$i]);	
									$BUSINESS_DATE='';
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									// echo $chaine[1]."<br>";
									$sequence_number=(trim(str_replace('"', '', $chaine[0])));	
									$buffer = explode(",", (trim(str_replace('"', '', $chaine[1]))));
									$bank_code=(trim(str_replace('"', '', $buffer[0])));	
									$activity_date=(trim(str_replace('"', '', $buffer[1])));	
									$buffer_2=(trim(str_replace('"', '', $buffer[2])));	
									$buffer_3=(trim(str_replace('"', '', $buffer[3])));	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$sequence_number.'</th>';
									 echo '<th>'.$bank_code.'</th>';
									 echo '<th>'.$activity_date.'</th>';
									 echo '<th>'.$buffer_2.'</th>';
									 echo '<th>'.$buffer_3.'</th>';
								 echo '</tr>';						
					


									// inserer_data_piece_joint_file_picko_vers_bdd($BUSINESS_DATE,	
									// $sequence_number,	
									// $bank_code,	
									// $date_create,	
									// $date_start,	
									// $date_end,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_joint_file_dispo_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=6  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>sequence_number</th>';
									 echo '<th>bank_code</th>';
									 echo '<th>date_create</th>';
									 echo '<th>date_start</th>';
									 echo '<th>date_end</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$chaine = explode(",", $tabfich[$i]);	
									$BUSINESS_DATE='';
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									// echo $chaine[1]."<br>";
									$sequence_number=(trim(str_replace('"', '', $chaine[0])));	
									$buffer = explode(",", (trim(str_replace('"', '', $chaine[1]))));
									$bank_code=(trim(str_replace('"', '', $buffer[0])));	
									$date_create=(trim(str_replace('"', '', $buffer[1])));	
									$date_start=(trim(str_replace('"', '', $buffer[2])));	
									$date_end=(trim(str_replace('"', '', $buffer[3])));	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$sequence_number.'</th>';
									 echo '<th>'.$bank_code.'</th>';
									 echo '<th>'.$date_create.'</th>';
									 echo '<th>'.$date_start.'</th>';
									 echo '<th>'.$date_end.'</th>';
								 echo '</tr>';						
					


									// inserer_data_piece_joint_file_dispo_vers_bdd($BUSINESS_DATE,	
									// $sequence_number,	
									// $bank_code,	
									// $date_create,	
									// $date_start,	
									// $date_end,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_rejet_per_hour_global_vers_bdd($date_courant,
									 $date_autho,
									 $day_autho,
									 $nbr_autho,
									 $bank_name,
									 $nbr_tech_reject,
									 $percentage_tech_reject,
									 $h0,
									 $h1,
									 $h2,
									 $h3,
									 $h4,
									 $h5,
									 $h6,
									 $h7,
									 $h8,
									 $h9,
									 $h10,
									 $h11,
									 $h12,
									 $h13,
									 $h14,
									 $h15,
									 $h16,
									 $h17,
									 $h18,
									 $h19,
									 $h20,
									 $h21,
									 $h22,
									 $h23,
									 $user_create,
									 $date_create,
									 $user_modif,
									 $date_modif,$csv)
{
				  if(($csv==1)){	
				   delete_data_piece_joint_per_hour_global_in_vers_bdd($date_courant,$bank_name);
				   echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';
				   }
				   $link = ma_db_connexion();
				   // $sql1="SELECT  `id_auto`  FROM `cbs_stand_in` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
							// AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
				  
				   // $result=mysqli_query($link,$sql1);
 							// if (!$result)
								// {
										// error_log("Erreur sql hps membres vr bdd  00000010 : ".mysqli_error($link));
										// die('ERREUR QUERY carte_gab_tpe vr bdd 00000010 !');
								// }
				   
					// if (mysqli_num_rows($result) == 0)
								// { 
									$sql2 = "INSERT INTO  `stat_file_rejet_per_hour_gl` (`id_auto`, `date_courant`, `date_autho`, `day_autho`, `nbr_autho`, `bank_name`, `nbr_tech_reject`, 
									`percentage_tech_reject`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `user_create`, `date_create`, `user_modif`, `date_modif`)
									VALUES (NULL,'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$date_autho)."',
									'".mysqli_real_escape_string($link,$day_autho)."','".mysqli_real_escape_string($link,$nbr_autho)."',
									'".mysqli_real_escape_string($link,$bank_name)."','".mysqli_real_escape_string($link,$nbr_tech_reject)."',
									'".mysqli_real_escape_string($link,$percentage_tech_reject)."','".mysqli_real_escape_string($link,$h0)."',
									'".mysqli_real_escape_string($link,$h1)."','".mysqli_real_escape_string($link,$h2)."',
									'".mysqli_real_escape_string($link,$h3)."','".mysqli_real_escape_string($link,$h4)."',
									'".mysqli_real_escape_string($link,$h5)."','".mysqli_real_escape_string($link,$h6)."',
									'".mysqli_real_escape_string($link,$h7)."','".mysqli_real_escape_string($link,$h8)."',
									'".mysqli_real_escape_string($link,$h9)."','".mysqli_real_escape_string($link,$h10)."',
									'".mysqli_real_escape_string($link,$h11)."','".mysqli_real_escape_string($link,$h12)."',
									'".mysqli_real_escape_string($link,$h13)."','".mysqli_real_escape_string($link,$h14)."',
									'".mysqli_real_escape_string($link,$h15)."','".mysqli_real_escape_string($link,$h16)."',
									'".mysqli_real_escape_string($link,$h17)."','".mysqli_real_escape_string($link,$h18)."',
									'".mysqli_real_escape_string($link,$h19)."','".mysqli_real_escape_string($link,$h20)."',
									'".mysqli_real_escape_string($link,$h21)."','".mysqli_real_escape_string($link,$h22)."',
									'".mysqli_real_escape_string($link,$h23)."','".mysqli_real_escape_string($link,$user_create)."',
									'".mysqli_real_escape_string($link,$date_create)."','".mysqli_real_escape_string($link,$user_modif)."',
									'".mysqli_real_escape_string($link,$date_modif)."')";
									// echo $sql2."<br>";
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps switch membre vr bdd  00000012: ".mysqli_error($link));
															die('ERREUR QUERY hps switch membre vr bdd 00000012 !');
											}	
								// }
					mysqli_close($link); 					
}

 								
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_joint_gab_ktc_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `gab_ktc` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  0000558850008 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 0000558850008 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `gab_ktc` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00009855500089 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00009855500089 !');
									}						
							}
					mysqli_close($link); 			
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_joint_gab_ktc_vers_bdd($date_courant,$bank_name,$C,$D,$E,$AA,$csv)
{
				  if(($AA==2) || ($csv==1)){	
				   delete_data_piece_joint_gab_ktc_vers_bdd($date_courant,$bank_name);
				   // echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';
				   }
				   $link = ma_db_connexion();
				   // $sql1="SELECT  `id_auto`  FROM `cbs_stand_in` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
							// AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
				  
				   // $result=mysqli_query($link,$sql1);
 							// if (!$result)
								// {
										// error_log("Erreur sql hps membres vr bdd  00000010 : ".mysqli_error($link));
										// die('ERREUR QUERY carte_gab_tpe vr bdd 00000010 !');
								// }
				   
					// if (mysqli_num_rows($result) == 0)
								// { 
									$sql2 = "INSERT INTO  `gab_ktc` (`id_auto`, `business_date`, `bank_name`, `gab_connectes`, `gab_deconnectes`, `atm_ktc`, `date_prise_charge`)
									VALUES ( NULL,'".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$bank_name)."',
									'".mysqli_real_escape_string($link,$D)."','".mysqli_real_escape_string($link,$C)."','".mysqli_real_escape_string($link,$E)."',NOW())";
									// echo $sql2."<br>";
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  0000787858750011 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 0000787858750011 !');
											}	
								// }
					mysqli_close($link); 					
}
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_joint_bkmvti_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>#</th>';
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>BANK_CODE</th>';
									 echo '<th>ID_TERMINAL</th>';
									 echo '<th>DATE_DERNIERE_TRANSACTION</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$chaine = explode(";", $tabfich[$i]);	
									$BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									$BANK_CODE=get_code_bank_csv(trim(str_replace('"', '', $chaine[1])));	
									// $ID_TERMINAL=str_replace('"', '', $chaine[2]);	
									// $DATE_DERNIERE_TRANSACTION=str_replace('"', '', $chaine[3]);	
	
									 echo '<tr>';			 
									 echo '<th>'.$i.'</th>';
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$BANK_CODE.'</th>';
									 echo '<th>'.$ID_TERMINAL.'</th>';
									 echo '<th>'.$DATE_DERNIERE_TRANSACTION.'</th>';
								 echo '</tr>';						
					
					
									// inserer_data_piece_joint_activite_transactionnelle_vers_bdd($business_date,

								
									// inserer_data_piece_joint_rejet_per_hour_global_vers_bdd($BUSINESS_DATE,	
									// $BANK_CODE,	
									// $ID_TERMINAL,	
									// $DATE_DERNIERE_TRANSACTION,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_csv_file_rejet_per_hour_global_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=35  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>date_autho</th>';
									 echo '<th>day_autho</th>';
									 echo '<th>nbr_autho</th>';
									 echo '<th>bank_name</th>';
									 echo '<th>nbr_tech_reject</th>';
									 echo '<th>percentage_tech_reject</th>';
									 echo '<th>h0</th>';
									 echo '<th>h1</th>';
									 echo '<th>h2</th>';
									 echo '<th>h3</th>';
									 echo '<th>h4</th>';
									 echo '<th>h5</th>';
									 echo '<th>h6</th>';
									 echo '<th>h7</th>';
									 echo '<th>h8</th>';
									 echo '<th>h9</th>';
									 echo '<th>h10</th>';
									 echo '<th>h11</th>';
									 echo '<th>h12</th>';
									 echo '<th>h13</th>';
									 echo '<th>h14</th>';
									 echo '<th>h15</th>';
									 echo '<th>h16</th>';
									 echo '<th>h17</th>';
									 echo '<th>h18</th>';
									 echo '<th>h19</th>';
									 echo '<th>h20</th>';
									 echo '<th>h21</th>';
									 echo '<th>h22</th>';
									 echo '<th>h23</th>';
									 echo '<th>user_create</th>';
									 echo '<th>date_create</th>';
									 echo '<th>user_modif</th>';
									 echo '<th>date_modif</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$date_courant=date("Y-m-d", strtotime($date_courant));
									$BUSINESS_DATE=$date_courant;
									$chaine = explode(";", $tabfich[$i]);	
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									$date_autho=(trim(str_replace('"', '', $chaine[0])));	
									$day_autho=(trim(str_replace('"', '', $chaine[1])));	
									$nbr_autho=(trim(str_replace('"', '', $chaine[2])));	
									$bank_name=(trim(str_replace('"', '', $chaine[3])));	
									$nbr_tech_reject=(trim(str_replace('"', '', $chaine[4])));	
									$percentage_tech_reject=(trim(str_replace('"', '', $chaine[5])));	
									$percentage_tech_reject=(trim(str_replace('%', '', $percentage_tech_reject)));	
									
									if(substr($percentage_tech_reject, 0,1)=="."){$percentage_tech_reject='0'.$percentage_tech_reject;}
									else{$percentage_tech_reject=$percentage_tech_reject;}
									// echo $percentage_tech_reject."----".substr($percentage_tech_reject, 0,1)."<br>";
									$h0=(trim(str_replace('"', '', str_replace(",",".",$chaine[6]))));	
									$h1=(trim(str_replace('"', '', str_replace(",",".",$chaine[7]))));	
									$h2=(trim(str_replace('"', '', str_replace(",",".",$chaine[8]))));	
									$h3=(trim(str_replace('"', '', str_replace(",",".",$chaine[9]))));	
									$h4=(trim(str_replace('"', '', str_replace(",",".",$chaine[10]))));	
									$h5=(trim(str_replace('"', '', str_replace(",",".",$chaine[11]))));	
									$h6=(trim(str_replace('"', '', str_replace(",",".",$chaine[12]))));	
									$h7=(trim(str_replace('"', '', str_replace(",",".",$chaine[13]))));	
									$h8=(trim(str_replace('"', '', str_replace(",",".",$chaine[14]))));	
									$h9=(trim(str_replace('"', '', str_replace(",",".",$chaine[15]))));	
									$h10=(trim(str_replace('"', '', str_replace(",",".",$chaine[16]))));	
									$h11=(trim(str_replace('"', '', str_replace(",",".",$chaine[17]))));	
									$h12=(trim(str_replace('"', '', str_replace(",",".",$chaine[18]))));	
									$h13=(trim(str_replace('"', '', str_replace(",",".",$chaine[19]))));	
									$h14=(trim(str_replace('"', '', str_replace(",",".",$chaine[20]))));	
									$h15=(trim(str_replace('"', '', str_replace(",",".",$chaine[21]))));	
									$h16=(trim(str_replace('"', '', str_replace(",",".",$chaine[22]))));	
									$h17=(trim(str_replace('"', '', str_replace(",",".",$chaine[23]))));	
									$h18=(trim(str_replace('"', '', str_replace(",",".",$chaine[24]))));	
									$h19=(trim(str_replace('"', '', str_replace(",",".",$chaine[25]))));	
									$h20=(trim(str_replace('"', '', str_replace(",",".",$chaine[26]))));	
									$h21=(trim(str_replace('"', '', str_replace(",",".",$chaine[27]))));	
									$h22=(trim(str_replace('"', '', str_replace(",",".",$chaine[28]))));	
									$h23=(trim(str_replace('"', '', str_replace(",",".",$chaine[29]))));	
									$user_create=(trim(str_replace('"', '', str_replace(",",".",$chaine[30]))));	
									$date_create=(trim(str_replace('"', '', str_replace(",",".",$chaine[31]))));	
									$user_modif=(trim(str_replace('"', '', str_replace(",",".",$chaine[32]))));	
									$date_modif=(trim(str_replace('"', '', str_replace(",",".",$chaine[33]))));	
						
	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$date_autho.'</th>';
									 echo '<th>'.$day_autho.'</th>';
									 echo '<th>'.$nbr_autho.'</th>';
									 echo '<th>'.$bank_name.'</th>';
									 echo '<th>'.$nbr_tech_reject.'</th>';
									 echo '<th>'.$percentage_tech_reject.'</th>';
									 echo '<th>'.$h0.'</th>';
									 echo '<th>'.$h1.'</th>';
									 echo '<th>'.$h2.'</th>';
									 echo '<th>'.$h3.'</th>';
									 echo '<th>'.$h4.'</th>';
									 echo '<th>'.$h5.'</th>';
									 echo '<th>'.$h6.'</th>';
									 echo '<th>'.$h7.'</th>';
									 echo '<th>'.$h8.'</th>';
									 echo '<th>'.$h9.'</th>';
									 echo '<th>'.$h10.'</th>';
									 echo '<th>'.$h11.'</th>';
									 echo '<th>'.$h12.'</th>';
									 echo '<th>'.$h13.'</th>';
									 echo '<th>'.$h14.'</th>';
									 echo '<th>'.$h15.'</th>';
									 echo '<th>'.$h16.'</th>';
									 echo '<th>'.$h17.'</th>';
									 echo '<th>'.$h18.'</th>';
									 echo '<th>'.$h19.'</th>';
									 echo '<th>'.$h20.'</th>';
									 echo '<th>'.$h21.'</th>';
									 echo '<th>'.$h22.'</th>';
									 echo '<th>'.$h23.'</th>';
									 echo '<th>'.$user_create.'</th>';
									 echo '<th>'.$date_create.'</th>';
									 echo '<th>'.$user_modif.'</th>';
									 echo '<th>'.$date_modif.'</th>';
									 echo '</tr>';							
					
					

									inserer_data_piece_joint_rejet_per_hour_global_vers_bdd($BUSINESS_DATE,	
									 $date_autho,
									 $day_autho,
									 $nbr_autho,
									 $bank_name,
									 $nbr_tech_reject,
									 $percentage_tech_reject,
									 $h0,
									 $h1,
									 $h2,
									 $h3,
									 $h4,
									 $h5,
									 $h6,
									 $h7,
									 $h8,
									 $h9,
									 $h10,
									 $h11,
									 $h12,
									 $h13,
									 $h14,
									 $h15,
									 $h16,
									 $h17,
									 $h18,
									 $h19,
									 $h20,
									 $h21,
									 $h22,
									 $h23,
									 $user_create,
									 $date_create,
									 $user_modif,
									 $date_modif,
									 $i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }

   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_gab_ktc_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=23  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>BANK_CODE</th>';
									 echo '<th>ATMsNotConnected</th>';
									 echo '<th>ATMsConnected</th>';
									 echo '<th>ATMs</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				// for( $i = 1 ; $i < count($tabfich) ; $i++ )
				for( $i = 1 ; $i <= 8 ; $i++ )
				{				
									$chaine = explode(";", $tabfich[$i]);	
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									$BUSINESS_DATE=$date_courant;
									list($BANK,$ATMsNotConnected,$ATMsConnected,$ATMs) = explode(',', $chaine[0]);										
									$BANK_CODE=get_code_bank_csv_ktc($BANK);	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$BANK_CODE.'</th>';
									 echo '<th>'.$ATMsNotConnected.'</th>';
									 echo '<th>'.$ATMsConnected.'</th>';
									 echo '<th>'.$ATMs.'</th>';
								 echo '</tr>';						
					

								
									inserer_data_piece_joint_gab_ktc_vers_bdd($BUSINESS_DATE,	
									$BANK_CODE,	
									$ATMsNotConnected,	
									$ATMsConnected,	
									$ATMs,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 } 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function delete_data_piece_csv_joint_tpe_masterstivity_vers_bdd($date_courant,$bank_name)
{
				   $link = ma_db_connexion();
				   $sql1="SELECT  `id_auto`  FROM `nb_carte_gab_tpe` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";				  
				   $result=mysqli_query($link,$sql1);
 					if (!$result)
						{
										error_log("Erreur sql hps membres vr bdd  00000008 : ".mysqli_error($link));
										die('ERREUR QUERY carte_gab_tpe vr bdd 00000008 !');
						}
				   
					if (mysqli_num_rows($result)>0)
							{ 
								$sql2 = "DELETE FROM `nb_carte_gab_tpe` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'";
										 // echo $sql2;
								$result2=mysqli_query($link,$sql2);
								if (!$result2)
									{
													error_log("Erreur sql hps membres vr bdd  00000009 : ".mysqli_error($link));
													die('ERREUR QUERY carte_gab_tpe vr bdd 00000009 !');
									}						
							}
					mysqli_close($link); 			
}
 
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function inserer_data_piece_csv_joint_file_mcc_vers_bdd($date_courant,$bank_name,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$AA,$csv)
{
				  if(($AA==2) || ($csv==1)){	
				   delete_data_piece_csv_joint_tpe_masterstivity_vers_bdd($date_courant,$bank_name);
				   // echo '<br>delete_data_piece_joint_transactionnelle_vers_vers_bdd<br>';
				   }
				   $link = ma_db_connexion();
				   // $sql1="SELECT  `id_auto`  FROM `nb_carte_gab_tpe` WHERE `business_date` = '".mysqli_real_escape_string($link,$date_courant)."'
							// AND  `bank_name` = '".mysqli_real_escape_string($link,$bank_name)."'";
				  
				   // $result=mysqli_query($link,$sql1);
 							// if (!$result)
								// {
										// error_log("Erreur sql hps membres vr bdd  00000010 : ".mysqli_error($link));
										// die('ERREUR QUERY carte_gab_tpe vr bdd 00000010 !');
								// }
				   // BUSINESS_DATE	BANK_CODE	NEW_ATM_NBR	ALL_ATM_NBR	NEW_CARD_NBR	ALL_CARD_NBR	ACTIVE_CARD_NBR	RENOUVELE_CARD_NBR	
				   // EXPR_CARD_NBR	ANNUL_CARD_NBR	
				   // ATT_ACTIVE_CARD_NBR	NEW_POS_NBR	ALL_POS_NBR	TP_MODIF_NBR

					// if (mysqli_num_rows($result) == 0)
								// { 
									$sql2 = "INSERT INTO  `nb_carte_gab_tpe` (`business_date`, `bank_name`, `new_atm_nbr`, `all_atm_nbr`, `new_card_nbr`,
									`all_card_nbr`, `nb_cartes_activees`, `nb_cartes_renouvelees`, `nb_cartes_expirees`, `nb_cartes_annulees`, 
									`nb_cartes_creees_att_activations`, `new_pos_nbr`, `all_pos_nbr`, `nb_tpe_config_modifiee`)
									VALUES ('".mysqli_real_escape_string($link,$date_courant)."','".mysqli_real_escape_string($link,$bank_name)."',
									'".mysqli_real_escape_string($link,$C)."','".mysqli_real_escape_string($link,$D)."','".mysqli_real_escape_string($link,$E)."',
									'".mysqli_real_escape_string($link,$F)."','".mysqli_real_escape_string($link,$G)."','".mysqli_real_escape_string($link,$H)."',
									'".mysqli_real_escape_string($link,$I)."','".mysqli_real_escape_string($link,$J)."','".mysqli_real_escape_string($link,$K)."',
									'".mysqli_real_escape_string($link,$L)."','".mysqli_real_escape_string($link,$M)."',
									'".mysqli_real_escape_string($link,substr($N, 0, -1))."')";
									// echo $sql2."<br>";
										$result2=mysqli_query($link,$sql2);
										if (!$result2)
											{
															error_log("Erreur sql hps membres vr bdd  000585500011 : ".mysqli_error($link));
															die('ERREUR QUERY carte_gab_tpe vr bdd 000585500011 !');
											}	
								// }
					mysqli_close($link); 					
}
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_csv_joint_file_mcc_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=14  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>sequence_number</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>activity_date</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '<th>buffer</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$chaine = explode(",", $tabfich[$i]);	
									$BUSINESS_DATE='';
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									// echo $chaine[1]."<br>";
									$sequence_number=(trim(str_replace('"', '', $chaine[0])));	
									$buffer = explode(",", (trim(str_replace('"', '', $chaine[1]))));
									$buffer_1=(trim(str_replace('"', '', $buffer[0])));	
									$buffer_2=(trim(str_replace('"', '', $buffer[1])));	
									$buffer_3=(trim(str_replace('"', '', $buffer[2])));	
									$buffer_4=(trim(str_replace('"', '', $buffer[3])));	
									$buffer_5=(trim(str_replace('"', '', $buffer[4])));	
									$buffer_6=(trim(str_replace('"', '', $buffer[5])));	
									$buffer_7=(trim(str_replace('"', '', $buffer[6])));	
									$activity_date=(trim(str_replace('"', '', $buffer[7])));	
									$buffer_9=(trim(str_replace('"', '', $buffer[8])));	
									$buffer_10=(trim(str_replace('"', '', $buffer[9])));	
									$buffer_11=(trim(str_replace('"', '', $buffer[10])));	
									$buffer_12=(trim(str_replace('"', '', $buffer[11])));	
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$sequence_number.'</th>';
									 echo '<th>'.$buffer_1.'</th>';
									 echo '<th>'.$buffer_2.'</th>';
									 echo '<th>'.$buffer_3.'</th>';
									 echo '<th>'.$buffer_4.'</th>';
									 echo '<th>'.$buffer_5.'</th>';
									 echo '<th>'.$buffer_6.'</th>';
									 echo '<th>'.$buffer_7.'</th>';
									 echo '<th>'.$activity_date.'</th>';
									 echo '<th>'.$buffer_9.'</th>';
									 echo '<th>'.$buffer_10.'</th>';
									 echo '<th>'.$buffer_11.'</th>';
									 echo '<th>'.$buffer_12.'</th>';
								 echo '</tr>';						
					


									// inserer_data_piece_csv_joint_file_mcc_vers_bdd($BUSINESS_DATE,	
									// $sequence_number,	
									// $bank_code,	
									// $date_create,	
									// $date_start,	
									// $date_end,	
									// $activity_date,0,$i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_csv_file_rejet_per_hour_vers_bdd($fichier,$date_courant,$libelle)
 {
echo '<div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier CSV '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">
			<table class="table table-striped">
				<tr><th COLSPAN=35  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									 echo '<tr>';			 
									 echo '<th>BUSINESS_DATE</th>';
									 echo '<th>date_autho</th>';
									 echo '<th>day_autho</th>';
									 echo '<th>nbr_autho</th>';
									 echo '<th>bank_name</th>';
									 echo '<th>nbr_tech_reject</th>';
									 echo '<th>percentage_tech_reject</th>';
									 echo '<th>h0</th>';
									 echo '<th>h1</th>';
									 echo '<th>h2</th>';
									 echo '<th>h3</th>';
									 echo '<th>h4</th>';
									 echo '<th>h5</th>';
									 echo '<th>h6</th>';
									 echo '<th>h7</th>';
									 echo '<th>h8</th>';
									 echo '<th>h9</th>';
									 echo '<th>h10</th>';
									 echo '<th>h11</th>';
									 echo '<th>h12</th>';
									 echo '<th>h13</th>';
									 echo '<th>h14</th>';
									 echo '<th>h15</th>';
									 echo '<th>h16</th>';
									 echo '<th>h17</th>';
									 echo '<th>h18</th>';
									 echo '<th>h19</th>';
									 echo '<th>h20</th>';
									 echo '<th>h21</th>';
									 echo '<th>h22</th>';
									 echo '<th>h23</th>';
									 echo '<th>user_create</th>';
									 echo '<th>date_create</th>';
									 echo '<th>user_modif</th>';
									 echo '<th>date_modif</th>';
									 echo '</tr>';	
				$tabfich=file($fichier); 
		
				for( $i = 1 ; $i < count($tabfich) ; $i++ )
				{				
									$date_courant=date("Y-m-d", strtotime($date_courant));
									$BUSINESS_DATE=$date_courant;
									$chaine = explode(";", $tabfich[$i]);	
									// $BUSINESS_DATE=get_date_courant_csv(trim(str_replace('"', '', $chaine[0])));	
									$date_autho=(trim(str_replace('"', '', $chaine[0])));	
									$day_autho=(trim(str_replace('"', '', $chaine[1])));	
									$nbr_autho=(trim(str_replace('"', '', $chaine[2])));	
									$bank_name=(trim(str_replace('"', '', $chaine[3])));	
									$nbr_tech_reject=(trim(str_replace('"', '', $chaine[4])));	
									$percentage_tech_reject=(trim(str_replace('"', '', $chaine[5])));
									
									$percentage_tech_reject=(trim(str_replace('%', '', $percentage_tech_reject)));										
									if(substr($percentage_tech_reject, 0,1)=="."){$percentage_tech_reject='0'.$percentage_tech_reject;}
									else{$percentage_tech_reject=$percentage_tech_reject;}	
									
									$h0=(trim(str_replace('"', '', str_replace(",",".",$chaine[6]))));	
									$h1=(trim(str_replace('"', '', str_replace(",",".",$chaine[7]))));	
									$h2=(trim(str_replace('"', '', str_replace(",",".",$chaine[8]))));	
									$h3=(trim(str_replace('"', '', str_replace(",",".",$chaine[9]))));	
									$h4=(trim(str_replace('"', '', str_replace(",",".",$chaine[10]))));	
									$h5=(trim(str_replace('"', '', str_replace(",",".",$chaine[11]))));	
									$h6=(trim(str_replace('"', '', str_replace(",",".",$chaine[12]))));	
									$h7=(trim(str_replace('"', '', str_replace(",",".",$chaine[13]))));	
									$h8=(trim(str_replace('"', '', str_replace(",",".",$chaine[14]))));	
									$h9=(trim(str_replace('"', '', str_replace(",",".",$chaine[15]))));	
									$h10=(trim(str_replace('"', '', str_replace(",",".",$chaine[16]))));	
									$h11=(trim(str_replace('"', '', str_replace(",",".",$chaine[17]))));	
									$h12=(trim(str_replace('"', '', str_replace(",",".",$chaine[18]))));	
									$h13=(trim(str_replace('"', '', str_replace(",",".",$chaine[19]))));	
									$h14=(trim(str_replace('"', '', str_replace(",",".",$chaine[20]))));	
									$h15=(trim(str_replace('"', '', str_replace(",",".",$chaine[21]))));	
									$h16=(trim(str_replace('"', '', str_replace(",",".",$chaine[22]))));	
									$h17=(trim(str_replace('"', '', str_replace(",",".",$chaine[23]))));	
									$h18=(trim(str_replace('"', '', str_replace(",",".",$chaine[24]))));	
									$h19=(trim(str_replace('"', '', str_replace(",",".",$chaine[25]))));	
									$h20=(trim(str_replace('"', '', str_replace(",",".",$chaine[26]))));	
									$h21=(trim(str_replace('"', '', str_replace(",",".",$chaine[27]))));	
									$h22=(trim(str_replace('"', '', str_replace(",",".",$chaine[28]))));	
									$h23=(trim(str_replace('"', '', str_replace(",",".",$chaine[29]))));	
									$user_create=(trim(str_replace('"', '', str_replace(",",".",$chaine[30]))));	
									$date_create=(trim(str_replace('"', '', str_replace(",",".",$chaine[31]))));	
									$user_modif=(trim(str_replace('"', '', str_replace(",",".",$chaine[32]))));	
									$date_modif=(trim(str_replace('"', '', str_replace(",",".",$chaine[33]))));	
						
									// $date_create=strftime("Y-m-d", strtotime($date_create));
									 echo '<tr>';			 
									 echo '<th>'.$BUSINESS_DATE.'</th>';
									 echo '<th>'.$date_autho.'</th>';
									 echo '<th>'.$day_autho.'</th>';
									 echo '<th>'.$nbr_autho.'</th>';
									 echo '<th>'.$bank_name.'</th>';
									 echo '<th>'.$nbr_tech_reject.'</th>';
									 echo '<th>'.$percentage_tech_reject.'</th>';
									 echo '<th>'.$h0.'</th>';
									 echo '<th>'.$h1.'</th>';
									 echo '<th>'.$h2.'</th>';
									 echo '<th>'.$h3.'</th>';
									 echo '<th>'.$h4.'</th>';
									 echo '<th>'.$h5.'</th>';
									 echo '<th>'.$h6.'</th>';
									 echo '<th>'.$h7.'</th>';
									 echo '<th>'.$h8.'</th>';
									 echo '<th>'.$h9.'</th>';
									 echo '<th>'.$h10.'</th>';
									 echo '<th>'.$h11.'</th>';
									 echo '<th>'.$h12.'</th>';
									 echo '<th>'.$h13.'</th>';
									 echo '<th>'.$h14.'</th>';
									 echo '<th>'.$h15.'</th>';
									 echo '<th>'.$h16.'</th>';
									 echo '<th>'.$h17.'</th>';
									 echo '<th>'.$h18.'</th>';
									 echo '<th>'.$h19.'</th>';
									 echo '<th>'.$h20.'</th>';
									 echo '<th>'.$h21.'</th>';
									 echo '<th>'.$h22.'</th>';
									 echo '<th>'.$h23.'</th>';
									 echo '<th>'.$user_create.'</th>';
									 echo '<th>'.$date_create.'</th>';
									 echo '<th>'.$user_modif.'</th>';
									 echo '<th>'.$date_modif.'</th>';
									 echo '</tr>';							
					
					

									inserer_data_piece_joint_rejet_per_hour_vers_bdd($BUSINESS_DATE,	
									 $date_autho,
									 $day_autho,
									 $nbr_autho,
									 $bank_name,
									 $nbr_tech_reject,
									 $percentage_tech_reject,
									 $h0,
									 $h1,
									 $h2,
									 $h3,
									 $h4,
									 $h5,
									 $h6,
									 $h7,
									 $h8,
									 $h9,
									 $h10,
									 $h11,
									 $h12,
									 $h13,
									 $h14,
									 $h15,
									 $h16,
									 $h17,
									 $h18,
									 $h19,
									 $h20,
									 $h21,
									 $h22,
									 $h23,
									 $user_create,
									 $date_create,
									 $user_modif,
									 $date_modif,
									 $i);											

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function importer_data_piece_joint_cbs_stand_in_vers_bdd($fichier,$date_courant,$libelle)
 {
 echo ' <div style=" margin:0 5px 0 5px;">
    <div class="page-header" >
        <h3><strong>Contenu du fichier XLS '.$libelle.'</strong></h3>
      </div>
      <div id="liste_detail_alerte"  class="row"  style=" margin:0 5px 0 5px;">';
	
			//$tmpfname = "test.xlsx";
		$url = $fichier;
		$filecontent = file_get_contents($url);
		$tmpfname = tempnam(sys_get_temp_dir(),"tmpxls");
		file_put_contents($tmpfname,$filecontent);
		
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		

		$boolGloblal=0;
		$AA=0;
		echo '<table class="table table-striped">';		
		for ($row = 1; $row <= $lastRow; $row++)		
		{
					if($worksheet->getCell('A'.$row)->getValue()=="BUSINESS_DATE")
					{
									echo '<tr><th COLSPAN=22  style="font-size:18px;font-weight:bold;text-align: center;color: #000000;background-color:#cecece;">'.$libelle.'</th></tr>';
									
									 echo '<tr>';			 
									 echo '<th>'.$worksheet->getCell('A'.$row)->getValue().'</th>';
									 echo '<th>CODE_NAME</th>';
									 echo '<th>'.$worksheet->getCell('B'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('C'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('D'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('E'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('F'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('G'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('H'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('I'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('J'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('K'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('L'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('M'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('N'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('O'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('P'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('Q'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('R'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('S'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('T'.$row)->getValue().'</th>';
									 echo '<th>'.$worksheet->getCell('U'.$row)->getValue().'</th>';
									 echo '</tr>';
									 
							$boolGloblal=1;
					}
					if($boolGloblal==1) //Disponibilite
						{
						if(($worksheet->getCell('A'.$row)->getValue()<>"") )
							{	
							if($AA==1){ 
								
							}
							if($AA>1)	
								{	
									 $business_date=get_date_courant(trim($worksheet->getCell('A'.$row)->getValue()));
									 $bank_name=get_code_bank(trim($worksheet->getCell('B'.$row)->getValue()));
									 echo '<tr>';			 
									 echo '<td>'.$business_date.'</td>';
									 echo '<td>'.$bank_name.'</td>';
									 echo '<td>'.$worksheet->getCell('B'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('C'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('D'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('E'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('F'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('G'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('H'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('I'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('J'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('K'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('L'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('M'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('N'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('O'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('P'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('Q'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('R'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('S'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('T'.$row)->getValue().'</td>';
									 echo '<td>'.$worksheet->getCell('U'.$row)->getValue().'</td>';
									 
									 echo '</tr>';
													 
									inserer_data_piece_joint_rejet_per_hour_vers_bdd($business_date,
									$bank_name, 
									$worksheet->getCell('C'.$row)->getValue(), 
									$worksheet->getCell('D'.$row)->getValue(), 
									$worksheet->getCell('E'.$row)->getValue(), 
									$worksheet->getCell('F'.$row)->getValue(), 
									$worksheet->getCell('G'.$row)->getValue(), 
									$worksheet->getCell('H'.$row)->getValue(), 
									$worksheet->getCell('I'.$row)->getValue(), 
									$worksheet->getCell('J'.$row)->getValue(), 
									$worksheet->getCell('K'.$row)->getValue(), 
									$worksheet->getCell('L'.$row)->getValue(), 
									$worksheet->getCell('M'.$row)->getValue(), 
									$worksheet->getCell('N'.$row)->getValue(), 
									$worksheet->getCell('O'.$row)->getValue(), 
									$worksheet->getCell('P'.$row)->getValue(), 
									$worksheet->getCell('Q'.$row)->getValue(), 
									$worksheet->getCell('R'.$row)->getValue(), 
									$worksheet->getCell('S'.$row)->getValue(), 
									$worksheet->getCell('T'.$row)->getValue(), 
									$worksheet->getCell('U'.$row)->getValue());									
								}
							$AA++;
							}
						else
							{
								$boolGloblal++;
							}
							
						}

			}
		echo '</table>';	
		
echo '</div>';	
echo '</div>';	
 }
?>